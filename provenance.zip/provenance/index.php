<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projeto final</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="js/script_button.js">

    <!-- Link script Scroll Mouse -->
    <script src="https://unpkg.com/scrollreveal@4"></script>
    <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
    <!-- Link Script Botton -->
    <link rel="icon" href="http://www.w3.org/2000/svg" sizes="32x32" />

</head>

<body>
    <!-- Dobra cabeçalho -->
    <header class="main_header" id="main_header">
        <div class="main_header_content">

            <a href="" class="logo"><img src="img/novaLogo.png" alt="Bem vindo ao projeto Provenance"></a>
            <nav class="main_header_content_menu">
                <ul>
                    <li><a href="">Inicio</a></li>
                    <li><a href="#container-phrase-body">Funcionalidades</a></li>
                    <li><a href="#sb-body">Saiba mais</a></li>
                    <li><a href="View/login.php">Login</a></li>
                    <li><a href="View/cadastrarUsuario.php">Cadastrar-me</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <!-- Fim dobra cabeçalho -->
    <!-- INICIO 1º DOBRA -->

    <main class="modal-link">
        <div class="color-main-logo">
            <div class="headline">
                <div class="main_cta" id="main_cta">
                    <article class="main_cta_content">
                        <div class="main_cta_content_spacer">
                            <header>
                                <h1>Um estoque bem gerenciado é a chave para um negócio bem-sucedido.</h1>
                            </header>
                            <!-- <div class="headline1"> -->
                            <p>Estoque organizado, farmácia de sucesso.</p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
        <!-- FIM 1º DOBRA -->

        <!-- INICIO SESSÃO FUNCIONALIDADES -->

        <section class="container-phrase-body" id="container-phrase-body">
            <div class="container-phrase">
                <div class="img-phrase">
                    <img src="img/logoProvenance.png" alt="Logo Provenance">
                </div>
                <h2><b>Conheça</b> todas as nossas <br><b class="phrase-func">Funcionalidades</b></br></h2>
            </div>
        </section>

        <div class="text-fun">
            <div class="card-container-div">
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun1.png" alt="Automotização do estoque">
                            <p class="heading">Automotização do estoque</p>
                        </div>
                        <div class="content">
                            <p>
                                Implementação de um sistema de gestão automatizado para controlar o estoque de
                                produtos
                                farmacêuticos.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun2.png" alt="Precisão no Controle">
                            <p class="heading">Precisão no Controle</p>
                        </div>
                        <div class="content">
                            <p>
                                Garantir que as operações de estoque sejam precisas, minimizando erros humanos.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun3.png" alt="Redução do Trabalho Manual">
                            <p class="heading">Redução do Trabalho Manual</p>
                        </div>
                        <div class="content">
                            <p>
                                Diminuir a necessidade de tarefas manuais, como contagem de inventário e
                                documentação de
                                dados.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun4.png" alt="Prevenção de Excesso">
                            <p class="heading">Prevenção de Excesso</p>
                        </div>
                        <div class="content">
                            <p>
                                Monitoramento constante dos níveis de estoque para evitar excesso ou falta de
                                produtos.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun5.png" alt="Visibilidade em Tempo Real">
                            <p class="heading">Visibilidade em Tempo Real</p>
                        </div>
                        <div class="content">
                            <p>
                                Fornecer informações em tempo real sobre os níveis de estoque, permitindo decisões
                                mais
                                informadas.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun6.png" alt="Alertas de Estoque Baixo">
                            <p class="heading">Alertas de Estoque Baixo</p>
                        </div>
                        <div class="content">
                            <p>
                                Sistema de alertas automáticos quando um item está prestes a esgotar, permitindo
                                ação
                                rápida
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun7.png" alt="Gerenciamento de Pedidos Automatizados">
                            <p class="heading">Gerenciamento de Pedidos Automatizados</p>
                        </div>
                        <div class="content">
                            <p>
                                Capacidade de gerar automaticamente pedidos de reposição de estoque quando
                                necessário.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-container">
                    <div class="card">
                        <div class="img-content">
                            <img src="img/png-fun8.png" alt="Ampla Aplicação em Diferentes Setores">
                            <p class="heading">Ampla Aplicação em Diferentes Setores</p>
                        </div>
                        <div class="content">
                            <p>
                                Extensão da solução para outros setores, como financeiro e comercial, para otimizar
                                operações em
                                toda a empresa.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- FIM SESSÃO FUNCIONALIDADES -->

        <!-- INICIO SESSÃO SAIBA MAIS -->
        <div class="sb-body" id="sb-body">
            <div class="container_principal_saiba_mais">
                <div class="sb-container">
                    <div class="sb-img">
                        <img src="img/img-sb1.svg" alt="">
                    </div>
                    <div class="sb-coment">
                        <h2>Benefícios da PROVENANCE</h2>
                        <p>A PROVENANCE automatiza o gerenciamento de estoque, melhorando eficiência, reduzindo erros e
                            facilitando decisões precisas no planejamento de produção e compras.</p>
                    </div>
                </div>
                <div class="sb-container2">
                    <div class="sb-img">
                        <img src="img/img-sb3.svg" alt="">
                    </div>
                    <div class="sb-coment">
                        <h2>Propósito da PROVENANCE</h2>
                        <p>A PROVENANCE proporcionamos eficiência e precisão no controle de estoque para atender às
                            necessidades
                            empresariais, incluindo a indústria farmacêutica. Isso reduz perdas financeiras, otimiza o
                            tempo e previne prejuízos nas operações comerciais.</p>
                    </div>
                </div>
                <div class="sb-container3">
                    <div class="sb-img">
                        <img src="img/img-sb5.svg" alt="">
                    </div>
                    <div class="sb-coment">
                        <h2>Aqui um pouco mais sobre o financeiro</h2>
                        <p>A PROVENANCE Contribui para a saúde financeira da empresa, reduzindo custos operacionais,
                            otimizando recursos, baseando decisões em dados e evitando perdas financeiras por erros no
                            controle de estoque, sendo essencial para o sucesso e sustentabilidade do negócio.</p>
                    </div>
                </div>
                <div class="sb-container4">
                    <div class="sb-img">
                        <img src="img/imagemFunc.svg" alt="">
                    </div>
                    <div class="sb-coment">
                        <h2>Soluções da PROVENANCE</h2>
                        <p>A PROVENANCE Uma solução completa de gerenciamento de estoque, automatizando o ciclo completo
                            para aprimorar a eficiência operacional e a gestão financeira das empresas.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- FIM SESSÃO SAIBA MAIS -->
        <!-- SEGUNDA TELA -->
        <section class="body-end">
            <div class="body-img-end">
                <img class="img-end" src="img/Version control-bro.svg" alt="Gestor">
            </div>
            <div class="text-end">
                <h1><strong class="text-strong">Apresentamos</strong> uma solução aprimorada
                    <br> para o seu <strong class="text-strong"> negócio </strong>
                </h1>
                <br>
                <p>Oferecemos a você a melhor opção de controle de estoque disponível no mercado.<br>Buscamos
                    proporcionar a melhor experiência e agilidade para o seu negócio. <br> Contrate agora os nossos
                    serviços e otimize a gestão do seu estoque com eficiência.</p>
                <br>
                <a href="Control/cadastrarUsuario.php"> 
                <button type="button" class="button-end">Cadastrar-me </button>
                </a>
            </div>
        </section>
        <!-- FIM SEGUNDA TELA -->
        <!-- INICIO SESSÃO OPT-IN -->
        <div class="wins-body">
            <div class="wins-complement">
                <img class="wins-img" src="img/basket.svg" alt="">
                <h1>Movimente sua farmacia</h1>
                <p>Aqui sua farmacia, ira bombar nos negocios</p>
            </div>
            <div class="wins-complement">
                <img class="wins-img" src="img/box2-heart.svg" alt="">
                <h1>Melhore a vida de todos </h1>
                <p>Ajude mais pessoas, visando a agilidade</p>
            </div>
            <div class="wins-complement">
                <img class="wins-img" src="img/clock-history.svg" alt="">
                <h1>Ganhe mais tempo</h1>
                <p>Ganhe mais tempo com o nosso site</p>
            </div>
        </div>
        <!-- FIM SESSÃO OPT-IN -->

    </main>

    <div id="btnTop">
        <botton class="arrow up"></botton>
    </div>

    <footer class="footer" id="footer">
        <div class="container">
            <div class="col1">
                <a href="#" class="brand">Provenance</a>
                <ul class="media-icons">
                    <li>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa-brands fa-facebook"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    </li>

                </ul>
            </div>
            <div class="col2">
                <ul class="menu">
                    <li><a href="#main_cta">Inicio</a></li>
                    <li><a href="#wrapper">Funcionalidades</a></li>
                    <li><a href="#sb-body">Saiba mais</a></li>
                    <li><a href="#footer">Contato</a></li>
                    <p>Aumentar a eficiência do controle de estoque através da automação e otimização de processos</p>
                </ul>
            </div>
            <div class="col3">
                <p>Assine nosso boletim de noticías</p>
                <form>
                    <div class="input-wrap">
                        <input type="email" placeholder="ex@gmail.com" /><button type="submit"><i
                                class="fa-solid fa-paper-plane"></i></button>
                    </div>
                </form>

            </div>
        </div>

        <div class="footer-bottom">
            <div class="mekk">
                <p>Provenance 2023 - Todos os direitos reservados</p>
            </div>
        </div>
    </footer>
    <script>
        // Script menu (mudar cor)
        window.addEventListener("scroll", function () {
            let header = document.querySelector('#main_header');
            header.classList.toggle('menuAnimation', window.scrollY > 0);
        })

        // Script do pop login
        // Seleciona o link e a janela modal
        var link = document.querySelector('.modal-link');
        var modal = document.querySelector('.modal_login');
        var overlay = document.querySelector('.overlay_login');
        var body = document.body;

        // Adiciona um listener de evento para o link
        link.addEventListener('click', function (event) {
            event.preventDefault(); // previne o comportamento padrão do link (navegar para outra página)

            overlay.style.display = 'block'; // exibe a camada escura
            modal.style.display = 'block'; // exibe a janela modal
            // body.classList.add('modal-open'); // desativa a rolagem
        });

        // Adiciona um listener de evento para a camada escura
        overlay.addEventListener('click', function () {
            overlay.style.display = 'none'; // oculta a camada escura
            modal.style.display = 'none'; // oculta a janela modal
            // body.classList.remove('modal-open'); // reativa a rolagem
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            coverflowEffect: {
                rotate: 0,
                stretch: 0,
                depth: 300,
                modifier: 1,
                slideShadows: false,
            },
            pagination: {
                el: ".swiper-pagination",
            },
        });
    </script>
    <!-- Script Scroll Mouse -->
    <script>
        ScrollReveal().reveal('.headline', { duration: 3000 });
        ScrollReveal().reveal('.headline1', { duration: 3300 });
    </script>
    <!-- Script Botton -->
    <script src="js/script_button.js"></script>

</body>

</html>