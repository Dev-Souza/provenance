 
function abrirNav(){
    document.getElementById("menuOculto").style.width = "250px";
    document.getElementById("contentPrincipal").style.marginLeft = "250px";
}
function fecharNav(){
    document.getElementById("menuOculto").style.width = "0px";
    document.getElementById("contentPrincipal").style.marginLeft = "0px";
}