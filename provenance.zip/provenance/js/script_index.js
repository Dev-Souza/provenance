// Script menu (mudar cor)
window.addEventListener("scroll", function(){
    let header = document.querySelector('#main_header');
    header.classList.toggle('menuAnimation', window.scrollY > 0);
})

// Script do pop login
// Seleciona o link e a janela modal
var link = document.querySelector('.modal-link');
var modal = document.querySelector('.modal_login');
var overlay = document.querySelector('.overlay_login');

// Adiciona um listener de evento para o link
link.addEventListener('click', function (event) {
    event.preventDefault(); // previne o comportamento padrão do link (navegar para outra página)

    overlay.style.display = 'block'; // exibe a camada escura
    modal.style.display = 'block'; // exibe a janela modal
});

// Adiciona um listener de evento para a camada escura
overlay.addEventListener('click', function () {
    overlay.style.display = 'none'; // oculta a camada escura
    modal.style.display = 'none'; // oculta a janela modal
});
