<?php
  session_start();
  require_once '../Model/usuarioDTO.php';
  require_once '../Model/usuarioDAO.php';
  
  //Valida se o usuário passou pela tela de login
  if(!isset($_POST["email"])){
    header("location:../View/login.php?msg=Acesso indevido!");
    exit();
  }
  $email = strip_tags($_POST["email"]);
  $senha = MD5($_POST["senha"]);
  $usuarioDAO = new UsuarioDAO();     
  $sucesso = $usuarioDAO->validarLogin($email, $senha);
  if($sucesso){
    $msg = "Login efetuado com sucesso"; 
	//Grava os principais dados de login do usuário
    $_SESSION["idUsuario"] = $sucesso["idUsuario"];
    $_SESSION["nomeUsuario"] = $sucesso["nomeUsuario"];
    $_SESSION["fotoUsuario"] = $sucesso["fotoUsuario"];
    $_SESSION["situacaoUsuario"] = $sucesso["situacaoUsuario"];
    $_SESSION["email"] = $sucesso["email"];
    $_SESSION["Perfil_idPerfil"] = $sucesso["Perfil_idPerfil"];
    if($_SESSION["Perfil_idPerfil"] == 1){
      header("location:../View/telaAdm.php?msg=$msg");
    }else if($_SESSION["Perfil_idPerfil"] == 2){
      header("location:../View/dashboardFarma.php?pagina=inicio&msg=$msg");
    }else{
      header("location:../View/abrirPedido.php?msg=$msg");
    }
    
    exit();
    
  } else {
    $msg = "Usuário ou senha inválido!";
  }
  header("location:../index.php?msg=$msg");
  exit();
