<?php
  session_start();
  //Testar se tem usuario logado
  if(!isset($_SESSION["idUsuario"])){
    header("location:../index.php?msg=Acesso indevido!");
  }
  if(!isset($_GET["idUsuario"])){
    header("location:../View/listarUsuario.php?msg=Usuário não informado!");
  }
  require_once '../Model/usuarioDTO.php';
  require_once '../Model/usuarioDAO.php';
  $idUsuario = $_GET["idUsuario"];
  

  $usuarioDAO = new UsuarioDAO();
        
  $sucesso = $usuarioDAO->excluirUsuario($idUsuario);

  if($sucesso){
    $msg = "Usuário excluído com sucesso!";   
  } else {
    $msg = "Aconteceu um problema para exclusão do Usuário".$sucesso;
  }
  header("location:../View/listarUsuario.php?msg=$msg");
  ?>