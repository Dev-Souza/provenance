<?php
  session_start();
  //Testar se tem usuario logado
  $perfil_idPerfilLogin = "";
  if(!isset($_SESSION["nomeUsuario"])){
    header("location:../index.php?msg=Acesso indevido!");
  } else {
    $perfil_idPerfilLogin = $_SESSION["idUsuario"];
  }

  //Testa se os dados vieram do Formulário
  if(!isset($_POST["nomeUsuario"])){
    header("location:../index.php?msg=Acesso indevido!");
  }

  

  require_once '../Model/usuarioDTO.php';
  require_once '../Model/usuarioDAO.php';
  $idUsuario = $_POST["idUsuario"];
  $nomeUsuario = strip_tags($_POST["nomeUsuario"]);
  
  if(!empty($_POST['fotoUsuarioOriginal'])){
    $fotoUsuario = $_POST["fotoUsuarioOriginal"];
    }
    else{
      $fotoUsuario = $_FILES["fotoUsuario"]["name"];
      $fotoUsuario = uniqid()."_".$fotoUsuario;
    }
    if(!empty($_FILES['fotoUsuario'])){
      $Arquivo = $_FILES["fotoUsuario"]["name"];
      $pastaDestino = "../uploadArq";
      $Arquivo = $fotoUsuario;
      $arqDestino = $pastaDestino.'/'.$Arquivo;
      //Função que faz o upload
      move_uploaded_file($_FILES["fotoUsuario"]["tmp_name"],$arqDestino);
    }
  $dtNascimento = $_POST["dtNascimento"];
  $cpf = $_POST["cpf"];
  $email = $_POST["email"];
  $senhaUsuarioOriginal = $_POST["senhaUsuarioOriginal"];
  $senha = $_POST["senha"];
  if(!empty($senha)){
    $senha = MD5($senha);
  } else {
    $senha = $senhaUsuarioOriginal;
  }
  
  $situacaoUsuario = $_POST["situacaoUsuario"];
  $perfil_idPerfil = $_POST["Perfil_idPerfil"];
  
  $usuarioDTO = new UsuarioDTO;
  $usuarioDTO->setIdUsuario($idUsuario);
  $usuarioDTO->setNomeUsuario($nomeUsuario);
  $usuarioDTO->setFotoUsuario($fotoUsuario);
  $usuarioDTO->setDtNascimento($dtNascimento);
  $usuarioDTO -> setCpf($cpf);
  $usuarioDTO -> setEmail($email);
  $usuarioDTO -> setSenha($senha);
  $usuarioDTO -> setSituacaoUsuario($situacaoUsuario);
  $usuarioDTO -> setPerfil_idPerfil($perfil_idPerfil);

  $usuarioDAO = new UsuarioDAO();
        
  $sucesso = $usuarioDAO->alterarUsuario($usuarioDTO);

  if($sucesso){
    $msg = "Cliente alterado com sucesso!";   
  } else {
    $msg = "Aconteceu um problema na alteração de dados.".$sucesso;
  }
  //Testa se o Administrador está Logado e vai para a listagem
  //PesquisarUsuario
  if($perfil_idPerfilLogin==3){
    header("location:../View/abrirPedido.php?msg=$msg");
    exit();
  } else {
    header("location:../index.php?msg=$msg");
  }
 
?>