<?php
session_start();
require_once '../Model/usuarioDTO.php';
require_once '../Model/usuarioDAO.php';
require_once '../View/cadastrarFuncionario.php';

if (!isset($_POST["nomeUsuario"])) {
  header("location:../index.php?msg=Acesso indevido!");
}

$Arquivo = "";
if (isset($_FILES["fotoUsuario"])) {
  $Arquivo = $_FILES["fotoUsuario"]["name"];
  $pastaDestino = "../uploadArq";
  $Arquivo = uniqid() . "_" . $Arquivo;
  $arqDestino = $pastaDestino . '/' . $Arquivo;
  //Função que faz o upload
  move_uploaded_file($_FILES["fotoUsuario"]["tmp_name"], $arqDestino);
}
$nomeUsuario = strip_tags($_POST["nomeUsuario"]);
$dtNascimento = $_POST["dtNascimento"];
$fotoUsuario = $Arquivo;
$cpf = $_POST["cpf"];
$genero = $_POST["genero"];
$email = $_POST["email"];
$senha = MD5($_POST["senha"]);
$token = $_POST["token"];
$situacaoUsuario = $_POST["situacaoUsuario"];
$Perfil_idPerfil = $_POST["Perfil_idPerfil"];

$usuarioDTO = new UsuarioDTO;
$usuarioDTO->setNomeUsuario($nomeUsuario);
$usuarioDTO->setFotoUsuario($fotoUsuario);
$usuarioDTO->setDtNascimento($dtNascimento);
$usuarioDTO->setCpf($cpf);
$usuarioDTO->setEmail($email);
$usuarioDTO->setSenha($senha);
$usuarioDTO->setToken($token);
$usuarioDTO->setSituacaoUsuario($situacaoUsuario);
$usuarioDTO->setPerfil_idPerfil($Perfil_idPerfil);

if ($_POST["token"] == "proj") {
  $usuarioDAO = new UsuarioDAO();

  $sucesso = $usuarioDAO->salvarUsuario($usuarioDTO);
  if ($sucesso) {
    $msg = "Usuário cadastrado com sucesso!";
  } else {
    $msg = "Aconteceu um problema no cadastramento<br>" . $sucesso;
    header("location:../View/cadastrarUsuario.php?msg=$msg");
    exit();
  }
  if ($_POST["Perfil_idPerfil"] == 4) {
    header("location:../View/abrirPedido.php?msg=$msg");
    exit();
  }
  header("location:../View/login.php?msg=$msg");
}else {
  $msg = "O token não foi informado corretamente" . $sucesso;
  header("location:../View/cadastrarUsuario.php?msg=$msg");
  exit();
}
