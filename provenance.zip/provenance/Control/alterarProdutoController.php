<?php
  // session_start();
  // //Testar se tem usuario logado
  // $perfil_idPerfilLogin = "";
  // if(!isset($_SESSION["nomeUsuario"])){
  //   header("location:../index.php?msg=Acesso indevido!");
  // } else {
  //   $perfil_idPerfilLogin = $_SESSION["idUsuario"];
  // }

  // //Testa se os dados vieram do Formulário
  // if(!isset($_POST["nomeUsuario"])){
  //   header("location:../index.php?msg=Acesso indevido!");
  // }

  require_once '../Model/produtoDTO.php';
  require_once '../Model/produtoDAO.php';
  $idProduto = $_POST["idProduto"];
  $codigoBarra = $_POST["codigoBarra"];
  $nomeProduto = strip_tags($_POST["nomeProduto"]);
  $dtValidade = $_POST["dtValidade"];
  $qtdeProduto = $_POST["qtdeProduto"];
  $peso = $_POST["peso"];
  $receita = $_POST["receita"];
  $precoCompra = $_POST["precoCompra"];
  $precoVenda = $_POST["precoVenda"];
  $remedioControlado = $_POST["remedioControlado"];
  if(!empty($_POST['imgProdOriginal'])){
  $imgProduto = $_POST["imgProdOriginal"];
  }
  else{
    $imgProduto = $_FILES["imgProduto"]["name"];
    $imgProduto = uniqid()."_".$imgProduto;
  }
  if(!empty($_FILES['imgProduto'])){
    $Arquivo = $_FILES["imgProduto"]["name"];
    $pastaDestino = "../uploadArq";
    $Arquivo = $imgProduto;
    $arqDestino = $pastaDestino.'/'.$Arquivo;
    //Função que faz o upload
    move_uploaded_file($_FILES["imgProduto"]["tmp_name"],$arqDestino);
  }
  $dtEntrada = $_POST["dtEntrada"];
  $categoria = $_POST["categoria"];
  $prateleira = $_POST["prateleira"];
  $estoqueMinimo = $_POST["estoqueMinimo"];
  
  $produtoDTO = new ProdutoDTO();
  $produtoDTO->setIdProduto($idProduto);
  $produtoDTO->setCodigoBarra($codigoBarra);
  $produtoDTO->setNomeProduto($nomeProduto);
  $produtoDTO->setDtValidade($dtValidade);
  $produtoDTO->setQtdeProduto($qtdeProduto);
  $produtoDTO->setPeso($peso);
  $produtoDTO->setReceita($receita);
  $produtoDTO->setPrecoCompra($precoCompra);
  $produtoDTO->setPrecoVenda($precoVenda);
  $produtoDTO->setremedioControlado($remedioControlado);
  $produtoDTO->setImgProduto($imgProduto);
  $produtoDTO->setDtEntrada($categoria);
  $produtoDTO->setPrateleira($prateleira);
  $produtoDTO->setEstoqueMinimo($estoqueMinimo);

  $produtoDAO = new ProdutoDAO();
        
  $sucesso = $produtoDAO->alterarProduto($produtoDTO);

  if($sucesso){
    $msg = "Produto alterado com sucesso!";   
    header("Location: ../View/dashboard.php?pagina=estoque&msg=$msg");
    exit();
  } else {
    $msg = "Aconteceu um problema na alteração do Produto.".$sucesso;
    header("location:../View/alterarProduto.php?msg=$msg");
    exit();
  }
 
?>