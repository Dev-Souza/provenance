<?php
  // session_start();
  // //Testar se tem usuario logado
  // if(!isset($_SESSION["idUsuario"])){
  //   header("location:../index.php?msg=Acesso indevido!");
  // }
  // if(!isset($_GET["idUsuario"])){
  //   header("location:../View/listarUsuario.php?msg=Usuário não informado!");
  // }
  require_once '../Model/produtoDTO.php';
  require_once '../Model/produtoDAO.php';

  $idProduto = $_GET["idProduto"];
  
  $produtoDAO = new ProdutoDAO();
        
  $sucesso = $produtoDAO->excluirProduto($idProduto);

  if($sucesso){
    $msg = "Produto excluído com sucesso!";   
  } else {
    $msg = "Aconteceu um problema para exclusão do Produto".$sucesso;
  }
  header("location:../View/dashboard.php?pagina=estoque&msg=$msg");
  ?>