<?php
  // session_start();
  // //Testar se tem usuario logado
  // if(!isset($_SESSION["idUsuario"])){
  //   header("location:../index.php?msg=Acesso indevido!");
  // }
  // if(!isset($_GET["idUsuario"])){
  //   header("location:../View/listarUsuario.php?msg=Usuário não informado!");
  // }
  require_once '../Model/pedidoDTO.php';
  require_once '../Model/pedidoDAO.php';

  $idPedido = $_GET["idPedido"];
  
  $pedidoDAO = new PedidoDAO();
        
  $sucesso = $pedidoDAO->excluirPedido($idPedido);

  if($sucesso){
    $msg = "Pedido excluído com sucesso!";   
  } else {
    $msg = "Aconteceu um problema para exclusão do Pedido".$sucesso;
  }
  header("location:../View/dashboard.php?pagina=pedidos&msg=$msg");
  ?>