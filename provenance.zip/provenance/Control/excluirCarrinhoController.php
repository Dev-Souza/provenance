<?php
session_start();
//Testar se tem usuario logado
if (!isset($_SESSION["idUsuario"])) {
  header("location:../index.php?msg=Acesso indevido!");
}
if (!isset($_GET["idPedido"])) {
  header("location:../View/telaAtendente.php?msg=Id do pedido não informado");
} else {
  $Pedido_idPedido = $_GET["idPedido"];
}

if (!isset($_GET["idUsuario"])) {
  header("location:../View/telaAtendente.php?msg=Id do Usuario não informado");
} else {
  $idUsuario = $_GET["idUsuario"];
}

if (!isset($_GET["idProduto"])) {
  header("location:../View/telaAtendente.php?msg=Id do produto não informado");
} else {
  $Produto_idProduto = $_GET["idProduto"];
}

if (!isset($_GET["precoTotalItem"])) {
  header("location:../View/telaAtendente.php?msg=preco do produto não informado");
} else {
  $precoTotalItem = $_GET["precoTotalItem"];
}

if (!isset($_GET["qtdeItem"])) {
  header("location:../View/telaAtendente.php?msg=quantidade do produto não informada");
} else {
  $qtd = $_GET["qtdeItem"];
}

require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';
$Pedido_idPedido = $_GET["idPedido"];
$Produto_idProduto = $_GET["idProduto"];
$precoTotalItem = $_GET['precoTotalItem'];
$qtd = $_GET["qtdeItem"];

$pedidoDAO = new PedidoDAO();
$sucesso = $pedidoDAO->excluirItemCarrinho($Pedido_idPedido, $Produto_idProduto, $precoTotalItem, $qtd);

if ($sucesso) {
  $msg = "Produto retirado do carrinho com sucesso!";
} else {
  $msg = "Aconteceu um problema para retirar o item do carrinho." . $sucesso;
}
header("location:pedidoController.php?idUsuario=$idUsuario");
?>