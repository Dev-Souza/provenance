<?php
session_start();
  require_once '../Model/produtoDTO.php';
  require_once '../Model/produtoDAO.php';
  require_once '../Model/pedidoDTO.php';
  require_once '../Model/pedidoDAO.php';

  $idPedido = $_POST['idPedido'];
  $idProduto = $_POST['idProduto'];
  $precoVenda = $_POST['precoVenda'];
  $qtd = $_POST['qtd'];

  $idUsuario = $_POST['idUsuario'];


  if($qtd < 1){
    $qtd = 1;
  }
  $itemDAO = new PedidoDAO();
  $itemDAO->incluirItemCarrinho($idPedido, $idProduto, $precoVenda, $qtd);
  header("location:../View/telaAtendente.php?idPedido=$idPedido&idUsuario=$idUsuario");
  ?>