<?php 
session_start();
require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';

$idPedido = $_GET['idPedido'];
$idUsuario = $_GET['idUsuario'];
$valorTotal = $_GET['valorTotal'];
$precoUnitario = $_GET['precoUnitario'];
$carrinhoDAO = new PedidoDAO();
$carrinhoDAO->fazerPagamento($idPedido, $idUsuario, $valorTotal, $precoUnitario);
header("location:../View/abrirPedido.php?msg=Compra efetuada com sucesso!");
?>