<?php
require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';
$idPedido = $_POST["idPedido"];
$dtPedido = $_POST["dtPedido"];
$valorPago = $_POST["valorPago"];
$situacaoPedido = $_POST["situacaoPedido"];
$Usuario_idUsuario = $_POST["Usuario_idUsuario"];

$pedidoDTO = new PedidoDTO;
$pedidoDTO->setIdPedido($idPedido);
$pedidoDTO->setDtPedido($dtPedido);
$pedidoDTO->setValorPago($valorPago);
$pedidoDTO->setSituacaoPedido($situacaoPedido);
$pedidoDTO->setUsuario_idUsuario($Usuario_idUsuario);

$pedidoDAO = new PedidoDAO();

$sucesso = $pedidoDAO->alterarPedido($pedidoDTO);

if ($sucesso) {
  $msg = "Pedido alterado com sucesso!";
} else {
  $msg = "Aconteceu um problema na alteração de dados." . $sucesso;
}

//Testa qual é o perfil
if ($perfil_idPerfilLogin == 2) {
  header("location:../View/dashboardFarma.php?pagina=pedidos&msg=$msg");
  exit();
} else {
  header("location:../View/dashboard.php?pagina=pedidos&msg=$msg");
  exit();
}


?>