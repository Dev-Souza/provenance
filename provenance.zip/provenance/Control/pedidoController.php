<?php
session_start();
require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';

if (!isset($_GET['idUsuario'])) {
  header("location:../index.php?msg=Acesso indevido");
}

$idUsuario = $_GET['idUsuario'];
$pedidoDAO = new PedidoDAO();

$pedido = $pedidoDAO->buscarPedidoAberto($idUsuario);

if (!$pedido) {
  $dtPedido = date('Y-m-d');  //DATA ATUAL
  $pedido = $pedidoDAO->incluirPedidoAberto($idUsuario, $dtPedido);
  $pedido = $pedidoDAO->buscarPedidoAberto($idUsuario);
  $_SESSION["idPedido"] = $pedido["idPedido"];
}

if ($pedido) {
  $temp = 'idUsuario='.$pedido["Usuario_idUsuario"]."&idPedido=".$pedido["idPedido"]."&nomeUsuario=".$pedido["nomeUsuario"];
  $msg = "Pedido cadastrado com sucesso!";
  header("location:../View/telaAtendente.php?$temp");

} else {
  $msg = "Erro ao cadastrar produto" . $sucesso;
}
//header("location:../View/dashboard.php?pagina=produto&msg=$msg");

?>