<?php
session_start();
  require_once '../Model/produtoDTO.php';
  require_once '../Model/produtoDAO.php';
  
  $Arquivo = "";
  if(isset($_FILES["imgProduto"])){
    $Arquivo = $_FILES["imgProduto"]["name"];
    $pastaDestino = "../uploadArq";
    $Arquivo = uniqid()."_".$Arquivo;
    $arqDestino = $pastaDestino.'/'.$Arquivo;
    //Função que faz o upload
    move_uploaded_file($_FILES["imgProduto"]["tmp_name"],$arqDestino);
  }

  $codigoBarra = $_POST["codigoBarra"];
  $nomeProduto = strip_tags($_POST["nomeProduto"]);
  $dtValidade = $_POST["dtValidade"];
  $qtdeProduto = $_POST["qtdeProduto"];
  $peso = $_POST["peso"];
  $receita = $_POST["receita"];
  $precoCompra = $_POST["precoCompra"];
  $precoVenda = $_POST["precoVenda"];
  $remedioControlado = $_POST["remedioControlado"];
  $imgProduto = $arqDestino;
  $dtEntrada = $_POST["dtEntrada"];
  $categoria = $_POST["categoria"];
  $prateleira = $_POST["prateleira"];
  $estoqueMinimo = $_POST["estoqueMinimo"];
  
  $produtoDTO = new ProdutoDTO();
  $produtoDTO->setCodigoBarra($codigoBarra);
  $produtoDTO->setNomeProduto($nomeProduto);
  $produtoDTO->setDtValidade($dtValidade);
  $produtoDTO->setQtdeProduto($qtdeProduto);
  $produtoDTO->setPeso($peso);
  $produtoDTO->setReceita($receita);
  $produtoDTO->setPrecoCompra($precoCompra);
  $produtoDTO->setPrecoVenda($precoVenda);
  $produtoDTO->setRemedioControlado($remedioControlado);
  $produtoDTO->setImgProduto($imgProduto);
  $produtoDTO->setDtEntrada($dtEntrada);
  $produtoDTO->setCategoria($categoria);
  $produtoDTO->setPrateleira($prateleira);
  $produtoDTO->setEstoqueMinimo($estoqueMinimo);
  
  $produtoDAO = new ProdutoDAO();
  $sucesso = $produtoDAO->salvarProduto($produtoDTO);
  if($sucesso){
    $msg = "Produto cadastrado com sucesso!";
    header("location:../View/dashboard.php?pagina=estoque&msg=$msg");
    exit();
  } else {
    $msg = "Erro ao cadastrar produto".$sucesso;
  }
  header("location:../View/dashboard.php?pagina=produto&msg=$msg");
  
?>
