<?php
session_start();
$idUsuario = "";
//Valida se houve login no sistema
if (!isset($_SESSION["idUsuario"])) {
    header("location:../index.php?msg=Acesso Indevido!");
}

//Testa se foi enviado um GET com idUsuario a ser alterado
if (isset($_GET["idUsuario"])) {
    $idUsuario = $_GET["idUsuario"];
} else {
    //Se um GET não foi passado, significa que a 
    //ALTERACAO é do próprio usuário logado. Usa o da SESSION
    $idUsuario = $_SESSION["idUsuario"];
}

$idUsuarioLogin = $_SESSION["idUsuario"];
$perfil_idPerfilLogin = $_SESSION["Perfil_idPerfil"];

require_once '../Model/usuarioDTO.php';
require_once '../Model/usuarioDAO.php';

$usuarioDAO = new UsuarioDAO();
$perfis = $usuarioDAO->listarPerfil();
$retorno = $usuarioDAO->PesquisarUsuarioPorId($idUsuario);
if (!$retorno) {
    if ($perfil_idPerfilLogin == 1) {
        header("location:listarUsuario.php?msg=Usuário não localizado!");
    } else {
        header("location:index.php?msg=Usuário não localizado!");
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Provenance</title>
    <link rel="stylesheet" href="../css/style_dashboard.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/style_paginaInicio.css">
</head>

<body>
    <nav id="menuOculto" class="menu_oculto">
        <a href="javascript:void(0)" class="btn_fechar" onclick="fecharNav()">
            <i class="bi bi-x-lg"></i>
        </a>
        <a href="?pagina=inicio">
            <i class="bi bi-house"></i>Inicio
        </a>
        <a href="?pagina=estoque">
            <i class="bi bi-box"></i>Estoque
        </a>
        <a href="?pagina=produto">
            <i class="bi bi-file-earmark-plus"></i>Produtos
        </a>
        <a href="?pagina=relatorios">
            <i class="bi bi-clipboard2-data"></i>Relatórios
        </a>
        <a href="?pagina=pedidos">
            <i class="bi bi-cart2"></i>Pedidos
        </a>
    </nav>
    <section id="contentPrincipal" class="contentPrincipal">
        <div class="menu_principal">
            <div class="first_menu_principal">
                <span onclick="abrirNav()">
                    <i class="bi bi-list"></i>
                </span>
            </div>
            <div class="perfil_menu">
                <h1> Olá, <?php echo $retorno["nomeUsuario"]; ?></h1>
                <img src="../uploadArq/<?php echo $retorno["fotoUsuario"]; ?>" onclick="toggleMenu()">
            </div>
            <div class="sub_menu_wrap" id="subMenu">
                <div class="sub_menu">
                    <div class="user_info">
                    <img src="../uploadArq/<?php echo $retorno["fotoUsuario"]; ?>">
                        <h3 class="title_perfil">
                            <?php echo $retorno["nomeUsuario"]; ?>
                        </h3>
                    </div>
                    <hr>
                    <a href="listarUsuario.php" class="sub_menu_link">
                        <i class="bi bi-pencil"></i>
                        <p>Usuários Provenance</p>
                        <i class="bi bi-chevron-right seta_customize"></i>
                    </a>
                    <a href="login.php" class="sub_menu_link">
                        <i class="bi bi-file-person"></i>
                        <p>Alterar perfil</p>
                        <i class="bi bi-chevron-right seta_customize"></i>
                    </a>
                    <a href="../index.php" class="sub_menu_link">
                        <i class="bi bi-box-arrow-left"></i>
                        <p>Sair</p>
                        <i class="bi bi-chevron-right seta_customize"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="content_side_bar">
            <?php
            if (isset($_GET['pagina'])) {
                switch ($_GET['pagina']) {
                    case 'inicio':
                        require_once("paginaInicio.php");
                        break;
                    case 'estoque':
                        require_once("paginaEstoque.php");
                        break;
                    case 'produto':
                        require_once("paginaProduto.php");
                        break;
                    case 'relatorios':
                        require_once("paginaRelatorio.php");
                        break;
                    case 'pedidos':
                        require_once("paginaPedido.php");
                        break;
                    default:
                        echo "NENHUMA OPÇÃO ESCOLHIDA";
                }
            }
            ?>
        </div>
    </section>
    <script>
        //Abrir e fechar side bar
        function abrirNav() {
            document.getElementById("menuOculto").style.width = "250px";
            document.getElementById("contentPrincipal").style.marginLeft = "250px";
        }

        function fecharNav() {
            document.getElementById("menuOculto").style.width = "0px";
            document.getElementById("contentPrincipal").style.marginLeft = "0px";
        }

        //Abrir dropdown do perfil
        let subMenu = document.getElementById("subMenu");

        function toggleMenu() {
            subMenu.classList.toggle("open_sub_menu");
        }
    </script>
</body>


</html>