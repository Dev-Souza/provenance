<?php
require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';
$pedidoDAO = new PedidoDAO();
$retorno = $pedidoDAO->pesquisarPedidoInner();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos efetuados</title>
    <link rel="stylesheet" href="../css/paginaEstoque.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <h2 class="titlle_list">Pedidos efetuados</h2>
    <hr>
    <div class="box-search">
        <input type="search" name="pesquisar" id="pesquisar" class="form-control w-25" placeholder="Pesquisar pedido">
        <button onclick="" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search"
                viewBox="0 0 16 16">
                <path
                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
        </button>
    </div>
    <div class="container_view">

        <div class="titlle_listar_produto">
            <div>
                <b>Nome Cliente</b>
            </div>
            <div>
                <b>Data Pedido</b>
            </div>
            <div>
                <b>Valor Total</b>
            </div>
            <div>
                <b>Valor Pago</b>
            </div>
            <div>
                <b>Situação</b>
            </div>
        </div>
        <?php
        if (!empty($retorno)) {
            // echo "<hr>";
            foreach ($retorno as $linha) {
                echo '<div class="container_principal">';

                //Nome Cliente
                echo '<div class="nomeUsuario">';
                echo $linha["nomeUsuario"];
                echo '</div>'; //fim nome cliente
        
                //Data pedido
                echo '<div class="dtPedido">';
                echo $linha["dtPedido"];
                echo '</div>'; //fim Data pedido
        
                //Valor Pago
                echo '<div class="valorTotal">';
                echo $linha["valorTotal"];
                echo '</div>'; //fim Valor Pago
        
                //Valor Pago
                echo '<div class="valorPago">';
                echo $linha["valorPago"];
                echo '</div>'; //fim Valor Pago
        
                //Situação Pedido
                echo '<div class="situacaoPedido">';
                echo $linha["situacaoPedido"];
                echo '</div>'; //fim Situação Pedido
        
                echo '</div>'; //Fim da DIV PRINCIPAL
                echo "<hr>";
            }
        } else {
            echo "<hr>NENHUM PEDIDO LOCALIZADO<hr>";
        }
        ?>
    </div>
    <script src="../js/sweetAlert.js"></script>
    <script>
        function eliminarPedido(id) {
            Swal.fire({
                title: "Realmente deseja excluir?",
                text: "Você não será capaz de reverter isso!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sim, exclua isso!"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redireciona para a página de exclusão
                    window.location.href = "../Control/excluirPedidoController.php?idProduto=" + id;
                }
            });
        }
    </script>
</body>

</html>