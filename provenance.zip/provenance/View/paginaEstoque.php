<?php
require_once '../Model/produtoDTO.php';
require_once '../Model/produtoDAO.php';
$produtoDAO = new ProdutoDAO();
$retorno = $produtoDAO->pesquisarProdutoss();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos em Estoque</title>
    <link rel="stylesheet" href="../css/paginaEstoque.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <h2 class="titlle_list">Produtos em Estoque</h2>
    <hr>
    <div class="box-search">
        <input type="search" name="pesquisar" id="pesquisar" class="form-control w-25" placeholder="Pesquisar produto">
        <button onclick="" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search"
                viewBox="0 0 16 16">
                <path
                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
        </button>
    </div>
    <div class="container_view">

        <div class="titlle_listar_produto">
            <div>
                <b>Foto</b>
            </div>
            <div>
                <b>Código</b>
            </div>
            <div>
                <b>Nome</b>
            </div>
            <div>
                <b>Validade</b>
            </div>
            <div>
                <b>Quantidade</b>
            </div>
            <div>
                <b>Preço</b>
            </div>
            <div>
                <b>Categoria</b>
            </div>
            <div>
                <b>Prateleira</b>
            </div>
            <div>
                <b>Ações</b>
            </div>
        </div>
        <?php
        if (!empty($retorno)) {
            // echo "<hr>";
            foreach ($retorno as $linha) {
                echo '<div class="container_principal">';

                //foto
                echo '<div class="imgProduto">';
                echo '<img src="../uploadArq/' . $linha["imgProduto"] .
                    '" width="70%">';
                echo '</div>'; //fim foto
                //Código de Barra
                echo '<div class="codigoBarra">';
                echo $linha["codigoBarra"];
                echo '</div>'; //fim Código de Barra
                //Nome Produto
                echo '<div class="nomeProduto">';
                echo $linha["nomeProduto"];
                echo '</div>'; //fim Nome Produto
                //Data Validade
                echo '<div class="dtValidade">';
                echo $linha["dtValidade"];
                echo '</div>'; //fim Data Validade
                //Quantidade
                echo '<div class="qtdeProduto">';
                echo $linha["qtdeProduto"];
                echo '</div>'; //fim Quantidade
                //Preço Venda
                echo '<div class="precoVenda">';
                echo 'R$ ' . $linha["precoVenda"];
                echo '</div>'; //fim Preço Venda
        
                //Categoria
                echo '<div class="categoria">';
                echo ' <select name="categoria"> ';
                
                $categorias = array(
                    "Acessórios",
                    "Analgésicos",
                    "Antialérgicos",
                    "Antibióticos",
                    "Antidepressivos",
                    "Antidiarreicos",
                    "Antitússicos",
                    "Antiácidos",
                    "Bem-Estar",
                    "Hidratantes",
                    "Higiene",
                    "Infantil",
                    "Oftálmicos",
                    "Suplementos",
                    "Vitaminas"
                );
                
                foreach ($categorias as $categoria) {
                    echo '<option value="' . $categoria . '"';
                    if ($linha["categoria"] == $categoria) {
                        echo ' selected="selected"';
                    }
                    echo '>' . $categoria . '</option>';
                }
                
                echo ' </select>';
                echo '</div>';//Fim categoria
        
                //Prateleira
                echo '<div class="prateleira">';
                echo $linha["prateleira"];
                echo '</div>'; //Fim prateleira
        
                // Inicio da função AÇÕES
                echo '<div class="acoesProduto">';
                echo '<a href="alterarProduto.php?idProduto=' . $linha["idProduto"] . '" class="alterar"><i class="bi bi-pencil-square"></i></a>';
                echo ' <button class="excluir" onclick="eliminarProduto(' . $linha["idProduto"] . ')"><i class="bi bi-trash"></i></button>';
                echo '</div>';
                // Fim da função AÇÕES
        
                echo '</div>'; //Fim da DIV PRINCIPAL
                echo "<hr>";
            }
        } else {
            echo "<hr>*** NENHUM PRODUTO LOCALIZADO ***<hr>";
        }
        ?>
    </div>
    <script src="../js/sweetAlert.js"></script>
    <script>
        function eliminarProduto(id) {
            Swal.fire({
                title: "Realmente deseja excluir?",
                text: "Você não será capaz de reverter isso!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sim, exclua isso!"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redireciona para a página de exclusão
                    window.location.href = "../Control/excluirProdutoController.php?idProduto=" + id;
                }
            });
        }
    </script>
</body>

</html>