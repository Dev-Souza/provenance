<?php
session_start();
$idUsuarioLogin = "";
$perfil_idPerfilLogin = "";

//Valida se houve login no sistema
if (isset($_SESSION["idUsuario"])) {
    //Passa o perfil de login para uma variável
    //O perfil de Administrador permite mudar o Perfil do Usuário
    //e a Situação 
    $perfil_idPerfilLogin = $_SESSION["Perfil_idPerfil"];
}

//incorpora o usuario DTO e DAO para poder carregar a lista de Pefis 
require_once "../Model/usuarioDTO.php";
require_once "../Model/usuarioDAO.php";
$usuarioDAO = new UsuarioDAO();
$perfis = $usuarioDAO->listarPerfil();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Administrador</title>
    <link rel="stylesheet" href="../css/cadastrarUsuario.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="main-cadastrar">
        <div class="left-cadastrar">
            <h1>Se cadastre<br>Prometo que não irá se arrepender!</h1>
            <img src="../img/imagemAdm.svg" class="left-cadastrar-image" alt="Pessoa levantando uma caixa">
        </div>
        <div class="right-cadastrar">
            <div class="card-cadastrar">
                <h1>Cadastrar-se</h1>
                <form action="../Control/cadastrarUsuarioController.php" method="POST" name="cadastrarUsuario" id="cadastrarUsuario" enctype="multipart/form-data">
                    <div class="textfield">
                        <label for="nomeUsuario">Nome completo</label>
                        <input type="text" name="nomeUsuario" id="nomeUsuario" placeholder="Digite o nome completo" required>
                    </div>
                    <div class="textfield">
                        <label for="fotoUsuario">Foto</label>
                        <input type="file" name="fotoUsuario">
                    </div>
                    <div class="textfield">
                        <label for="dtNascimento">Data de Nascimento</label>
                        <input type="date" name="dtNascimento">
                    </div>
                    <div class="textfield">
                        <label for="cpf">CPF</label>
                        <input type="text" name="cpf" placeholder="Digite o CPF">
                    </div>
                    <div class="textfield">
                        <label for="genero">Gênero</label>
                        <select name="genero">
                            <option value="#">Selecione uma opção</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Feminimo">Feminino</option>
                            <option value="Outro">Outro</option>
                        </select>
                    </div>
                    <div class="textfield">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Digite o email" required>
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" id="senha" placeholder="Digite a senha" required>
                    </div>
                    <div class="textfield">
                        <label for="token">Token</label>
                        <input type="text" name="token" id="token" placeholder="Digite o token informado" required>
                    </div>

                    <input type="hidden" name="Perfil_idPerfil" value="1">
                    <input type="hidden" name="situacaoUsuario" value="Ativo">

                    <input type="submit" class="btn-cadastrar" id="btnCadastrar" value="Cadastrar-se" onclick="atomicidade(event)">
                </form>
            </div>
        </div>
    </div>
    <script src="../js/sweetAlert.js"></script>
    <script>
        function atomicidade(event) {
            event.preventDefault(); // Impede o envio padrão do formulário

            let token = document.getElementById("token").value;

            if (token.toLowerCase() === "proj") {
                Swal.fire({
                    title: "Cadastrado com sucesso!",
                    text: "As informações de administrador foram cadastradas.",
                    icon: "success"
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Submeter o formulário
                        document.getElementById("cadastrarUsuario").submit();
                    }
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "O token inserido está incorreto!",
                    footer: '<a href="../index.php">Entre em contato com o adm do sistema.</a>'
                });
            }
        }
    </script>
</body>

</html>