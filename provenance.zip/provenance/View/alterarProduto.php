<?php
session_start();
if (isset($_GET["idProduto"])) {
    $idProduto = $_GET["idProduto"];
} else {
    $idProduto = $_SESSION["idProduto"];
}

require_once '../Model/produtoDTO.php';
require_once '../Model/produtoDAO.php';
$produtoDAO = new ProdutoDAO();
$retorno = $produtoDAO->pesquisarProdutoPorId($idProduto);

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/alterarProduto.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Alterar Produto</title>
</head>

<body>
    <!--DOBRA CABEÇALHO-->
    <header class="main_header" id="main_header">
        <div class="main_header_content">
            <img src="../img/novaLogo.png" alt="Bem vindo ao projeto Provenance">
            <nav class="main_header_content_menu">
                <ul>
                    <li><a href="../View/dashboard.php?pagina=estoque">Voltar</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <!--FIM DOBRA CABEÇALHO-->
    <div class="container_principal">
        <div class="titlle_top">
            <h2>Alterar Produto</h2>
        </div>
        <hr>
        <div class="content_alterar_produto">
            <form name="alterarProduto" id="alterarProduto" action="../Control/alterarProdutoController.php" method="POST" enctype="multipart/form-data">
                <div class="form_alterar_produto">
                    <div class="input_group">
                        <input type="hidden" name="idProduto" value="<?php echo $retorno["idProduto"]; ?>">
                        <label for="codigoBarra">Código de Barra</label><br>
                        <input type="text" name="codigoBarra" value="<?php echo $retorno["codigoBarra"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="nomeProduto">Nome Produto</label><br>
                        <input type="text" name="nomeProduto" value="<?php echo $retorno["nomeProduto"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="dtValidade">Data De Validade</label><br>
                        <input type="date" name="dtValidade" value="<?php echo $retorno["dtValidade"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="qtdeProduto">Quantidade</label><br>
                        <input type="number" name="qtdeProduto" value="<?php echo $retorno["qtdeProduto"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="peso">Peso Produto</label><br>
                        <input type="number" name="peso" value="<?php echo $retorno["peso"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="precoCompra">Preço de Compra</label><br>
                        <input type="number" name="precoCompra" value="<?php echo $retorno["precoCompra"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="precoVenda">Preço de Venda</label><br>
                        <input type="number" name="precoVenda" value="<?php echo $retorno["precoVenda"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="receita">Tem Receita?</label><br>
                        <select name="receita">
                            <?php
                            if ($retorno["receita"] == "Sim") {
                                echo '<option value="Sim" selected=selected>Sim</option>';
                            } else {
                                echo '<option value="Sim">Sim</option>';
                            }
                            if ($retorno["receita"] == "Não") {
                                echo '<option value="Não" selected=selected>Não</option>';
                            } else {
                                echo '<option value="Não">Não</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="input_group">
                        <label for="remedioControlado">É Remédio Controlado?</label><br>
                        <select name="remedioControlado">
                            <?php
                            if ($retorno["remedioControlado"] == "Sim") {
                                echo '<option value="Sim" selected=selected>Sim</option>';
                            } else {
                                echo '<option value="Sim">Sim</option>';
                            }
                            if ($retorno["remedioControlado"] == "Não") {
                                echo '<option value="Não" selected=selected>Não</option>';
                            } else {
                                echo '<option value="Não">Não</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="input_group">
                        <label for="imgProduto">Imagem do Produto</label><br>
                        <input type="hidden" name="imgProdOriginal" value="<?php echo $retorno["imgProduto"]; ?>">
                        <input type="file" name="imgProduto" >
                    </div>
                    <div class="input_group">
                        <label for="dtEntrada">Data de Entrada Produto</label><br>
                        <input type="date" name="dtEntrada" value="<?php echo $retorno["dtEntrada"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="categoria">Categoria</label><br>
                        <select name="categoria">
                            <?php
                            if ($retorno["categoria"] == "Acessórios") {
                                echo '<option value="Acessórios" selected=selected>Acessórios</option>';
                            } else {
                                echo '<option value="Acessórios">Acessórios</option>';
                            }
                            if ($retorno["categoria"] == "Analgésicos") {
                                echo '<option value="Analgésicos" selected=selected>Analgésicos</option>';
                            } else {
                                echo '<option value="Analgésicos">Analgésicos</option>';
                            }
                            if ($retorno["categoria"] == "Antialérgicos") {
                                echo '<option value="Antialérgicos" selected=selected>Antialérgicos</option>';
                            } else {
                                echo '<option value="Antialérgicos">Antialérgicos</option>';
                            }
                            if ($retorno["categoria"] == "Antibióticos") {
                                echo '<option value="Antibióticos" selected=selected>Antibióticos</option>';
                            } else {
                                echo '<option value="Antibióticos">Antibióticos</option>';
                            }
                            if ($retorno["categoria"] == "Antidepressivos") {
                                echo '<option value="Antidepressivos" selected=selected>Antidepressivos</option>';
                            } else {
                                echo '<option value="Antidepressivos">Antidepressivos</option>';
                            }
                            if ($retorno["categoria"] == "Antidiarreicos") {
                                echo '<option value="Antidiarreicos" selected=selected>Antidiarreicos</option>';
                            } else {
                                echo '<option value="Antidiarreicos">Antidiarreicos</option>';
                            }
                            if ($retorno["categoria"] == "Antitússicos") {
                                echo '<option value="Antitússicos" selected=selected>Antitússicos</option>';
                            } else {
                                echo '<option value="Antitússicos">Antitússicos</option>';
                            }
                            if ($retorno["categoria"] == "Antiácidos") {
                                echo '<option value="Antiácidos" selected=selected>Antiácidos</option>';
                            } else {
                                echo '<option value="Antiácidos">Antiácidos</option>';
                            }
                            if ($retorno["categoria"] == "Bem-Estar") {
                                echo '<option value="Bem-Estar" selected=selected>Bem-Estar</option>';
                            } else {
                                echo '<option value="Bem-Estar">Bem-Estar</option>';
                            }
                            if ($retorno["categoria"] == "Hidratantes") {
                                echo '<option value="Hidratantes" selected=selected>Hidratantes</option>';
                            } else {
                                echo '<option value="Hidratantes">Hidratantes</option>';
                            }
                            if ($retorno["categoria"] == "Higiene") {
                                echo '<option value="Higiene" selected=selected>Higiene</option>';
                            } else {
                                echo '<option value="Higiene">Higiene</option>';
                            }
                            if ($retorno["categoria"] == "Infantil") {
                                echo '<option value="Infantil" selected=selected>Infantil</option>';
                            } else {
                                echo '<option value="Infantil">Infantil</option>';
                            }
                            if ($retorno["categoria"] == "Oftálmicos") {
                                echo '<option value="Oftálmicos" selected=selected>Oftálmicos</option>';
                            } else {
                                echo '<option value="Oftálmicos">Oftálmicos</option>';
                            }
                            if ($retorno["categoria"] == "Suplementos") {
                                echo '<option value="Suplementos" selected=selected>Suplementos</option>';
                            } else {
                                echo '<option value="Suplementos">Suplementos</option>';
                            }
                            if ($retorno["categoria"] == "Vitaminas") {
                                echo '<option value="Vitaminas" selected=selected>Vitaminas</option>';
                            } else {
                                echo '<option value="Vitaminas">Vitaminas</option>';
                            }
                            ?>
                            
                        </select>
                    </div>
                    <div class="input_group">
                        <label for="prateleira">Prateleira</label><br>
                        <input type="text" name="prateleira" value="<?php echo $retorno["prateleira"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="estoqueMinimo">Estoque Mínimo</label><br>
                        <input type="number" name="estoqueMinimo" value="<?php echo $retorno["estoqueMinimo"]; ?>">
                    </div>
                    <input type="submit" value="Salvar Alteração" onclick="atomicidade(event)" class="btn-alterar">
                </div>
            </form>
        </div>
    </div>
    <script>
        function atomicidade(event) {
            event.preventDefault(); // Impede o envio padrão do formulário
            Swal.fire({
                title: "Alterado com sucesso!",
                text: "Informações de produto foram alteradas",
                icon: "success"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Submeter o formulário
                    document.getElementById("alterarProduto").submit();
                }
            });
        }
    </script>
</body>

</html>