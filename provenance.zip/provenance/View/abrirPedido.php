<?php
session_start();
$idUsuario = "";
if (!isset($_SESSION["idUsuario"])) {
    header("location:../index.php?msg=Acesso Indevido!");
}
$idUsuario = $_SESSION["idUsuario"];
//$perfil_idPerfil = $_SESSION["perfil_idPerfil"];
require_once '../Model/usuarioDTO.php';
require_once '../Model/usuarioDAO.php';
$usuarioDAO = new UsuarioDAO();
$retorno = $usuarioDAO->PesquisarUsuario();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Cliente</title>
    <link rel="stylesheet" href="../css/listarUsuario.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>

<body>
    <!--DOBRA CABEÇALHO-->
    <header class="main_header" id="main_header">
        <div class="main_header_content">
            <img src="../img/novaLogo.png" alt="Bem vindo ao projeto Provenance">
            <nav class="main_header_content_menu">
                <ul>
                    <li><a href="cadastrarCliente.php">Cadastrar Cliente</a></li>
                    <li><a href="login.php">Voltar</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!--FIM DOBRA CABEÇALHO-->
    <div class="container_view">
        <h1 class="titlle_list">Abrir Pedido</h1>
        <div class="titlle_listar_usuario">
        
            <div>
                <b>Nome</b>
            </div>
            <div>
                <b>Email</b>
            </div>
            <div>
                <b>Cargo</b>
            </div>
            <div>
                <b>Situação</b>
            </div>
            <div>
                <b>Ações</b>
            </div>
        </div>
        <?php
        if (!empty($retorno)) {
            // echo "<hr>";
            foreach ($retorno as $linha) {
                if ($linha["Perfil_idPerfil"] == 4) {
                    echo '<div class="container_principal">';

                
        
                    //nome
                    echo '<div class="nomeUsuario">';
                    echo $linha["nomeUsuario"];
                    echo '</div>'; //fim nome
                    // //gênero
                    // echo '<div class="genero">';
                    // echo $linha["genero"];
                    // echo '</div>'; //fim gênero
                    // //Data de Nascimento
                    // echo '<div class"dtNascimento">';
                    // echo $linha["dtNascimento"];
                    // echo '</div>';
                    //email
                    echo '<div class="email">';
                    echo $linha["email"];
                    echo '</div>'; //fim email
        
                    //Cargo
                    echo '<div class="Perfil_idPerfil">';
                    echo $linha['nomePerfil'];
                    echo '</div>';
                    //Fim cargo
        

                    //situação
                    echo '<div class="situacaoUsuario">';
                    echo ' <select name="situacaoUsuario"> ';
                    if ($linha["situacaoUsuario"] == "Ativo") {
                        echo ' <option value="Ativo" selected="selected">Ativo</option>';
                    } else {
                        echo ' <option value="Ativo">Ativo</option>';
                    }
                    if ($linha["situacaoUsuario"] == "Inativo") {
                        echo ' <option value="Inativo" selected="selected">Inativo</option>';
                    } else {
                        echo ' <option value="Inativo">Inativo</option>';
                    }
                    echo '</select>';
                    echo '</div>';

                    // Inicio da função AÇÕES
                    echo '<div class="acoesUsuario">';
                    echo '<a href="../Control/pedidoController.php?idUsuario=' . $linha["idUsuario"] . '" class="carrinho">';
                    echo '<i class="bi bi-cart size-cart" id="cart-icon"></i>';
                    echo '</a>';
                    echo '<a href="alterarCliente.php?idUsuario=' .
                        $linha["idUsuario"] . '" class="alterar"><i class="bi bi-pencil-square"></i></a>';
                    echo ' <button class="excluir" onclick="eliminarPerfil(' . $linha["idUsuario"] . ')"><i class="bi bi-trash"></i></button>';
                    echo '</div>';
                    // Fim da função AÇÕES
        
                    echo '</div>'; //Fim da DIV PRINCIPAL
                    echo "<hr>";
                }
            }

        } else {
            echo "<hr>*** NENHUM USUÁRIO LOCALIZADO ***<hr>";
        }
        ?>
    </div>
    <script src="../js/sweetAlert.js"></script>
    <script>
        function eliminarPerfil(id) {
            Swal.fire({
                title: "Realmente deseja excluir?",
                text: "Você não será capaz de reverter isso!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sim, exclua isso!"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redireciona para a página de exclusão
                    window.location.href = "../Control/excluirClienteController.php?idUsuario=" + id;
                }
            });
        }
    </script>
</body>

</html>