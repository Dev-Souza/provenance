<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela Administrador</title>
    <link rel="stylesheet" href="../css/telaAdm.css">
</head>

<body>
    <!--DOBRA CABEÇALHO-->
    <header class="main_header" id="main_header">
        <div class="main_header_content">
            <img src="../img/novaLogo.png" alt="Bem vindo ao projeto Provenance">
            <nav class="main_header_content_menu">
                <ul>
                    <li><a href="../index.php">Voltar</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!--FIM DOBRA CABEÇALHO-->

    <!-- INICIO SESSÃO OPÇÃO -->
    <main>
        <div>
            <section class="main_course">
                <header class="main_course_header"></header>
                <div class="ajust">
                    <article>
                        <h2>Sistema Provenance</h2>
                        <header>
                            <p>
                                <a href="dashboard.php?pagina=inicio">
                                    <img src="../img/imagemSistemaAdm.svg" alt="Sistema Provenance" title="Sistema" width="300" height="200">
                                </a>
                            </p>
                        </header>
                    </article>
                    <article>
                        <h2>Usuários Provenance</h2>
                        <header>
                            <p>
                                <a href="listarUsuario.php">
                                    <img src="../img/imagemUsuarioAdm.svg" alt="Usuários Provenance" title="Usuários" width="300" height="200">
                                </a>
                            </p>
                        </header>
                    </article>

                </div>
            </section>
        </div>
    </main>
    <!-- FIM SESSÃO OPÇÃO -->

</body>

</html>