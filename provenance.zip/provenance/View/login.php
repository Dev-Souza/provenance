<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
    <div class="main-login">
        <div class="left-login">
            <h1>Faça login<br>Que bom você aqui de volta!</h1>
            <img src="../img/logisticAnimada.svg" class="left-login-image" alt="Pessoa levantando uma caixa">
        </div>
        <div class="right-login">
            <div class="card-login">
                <h1>LOGIN</h1>
                <form role="form" action="../Control/loginController.php" name="login" method="POST">
                    <div class="textfield">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Digite seu email">
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" id="senha" placeholder="Digite sua senha">
                    </div>
                    <button class="btn-login">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>