<?php
require_once '../Model/produtoDTO.php';
require_once '../Model/produtoDAO.php';
$produtoDAO = new ProdutoDAO();
//Descobrindo a quantidade de produtos em estoque
$qtdeProduto = $produtoDAO->qtdeProduto();
//Descobrindo a quantia que tem em estoque
$quantiaEstoque = $produtoDAO->quantiaEstoque();
//Descobrindo a quantidade vendida
$qtdeVendida = $produtoDAO->qtdeVendida();
//Descobrindo a quantidade de produtos que falta 15 dias para vencer
$qtdeVencimento = $produtoDAO->qtdeVencimento()
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Admin Dashboard</title>
  <!-- Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
  <link rel="stylesheet" href="../css/paginaInicio.css">
</head>

<body>
  <div class="grid-container">
    <main class="main-container">

      <div class="main-cards">

        <div class="card">
          <div class="card-inner">
            <p class="text-primary">PRODUTOS ESTOQUE</p>
            <span class="material-icons-outlined text-blue">inventory_2</span>
          </div>
          <span class="text-primary font-weight-bold">
            <?php
            if (is_array($qtdeProduto)) {
              foreach ($qtdeProduto as $subarray) {
                foreach ($subarray as $valor) {
                  echo $valor;
                }
              }
            } else {
              echo "O valor retornado não é um array.";
            }
            ?>
          </span>
        </div>

        <div class="card">
          <div class="card-inner">
            <p class="text-primary">TOTAL EM ESTOQUE</p>
            <span class="material-icons-outlined text-orange">add_shopping_cart</span>
          </div>
          <span class="text-primary font-weight-bold">
            <?php
            if (is_array($quantiaEstoque)) {
              foreach ($quantiaEstoque as $subarray) {
                foreach ($subarray as $valor) {
                  echo 'R$ ' . $valor;
                }
              }
            } else {
              echo "O valor retornado não é um array.";
            }
            ?>
          </span>
        </div>

        <div class="card">
          <div class="card-inner">
            <p class="text-primary">PRODUTOS VENDIDOS</p>
            <span class="material-icons-outlined text-green">shopping_cart</span>
          </div>
          <span class="text-primary font-weight-bold">
            <?php
            if (is_array($qtdeVendida)) {
              foreach ($qtdeVendida as $subarray) {
                foreach ($subarray as $valor) {
                  echo $valor;
                }
              }
            } else {
              echo "O valor retornado não é um array.";
            }
            ?>
          </span>
        </div>

        <div class="card">
          <div class="card-inner">
            <p class="text-primary">PRODUTOS A VENCER</p>
            <span class="material-icons-outlined text-red">notification_important</span>
          </div>
          <span class="text-primary font-weight-bold">
            <?php
            if (is_array($qtdeVencimento)) {
              foreach ($qtdeVencimento as $subarray) {
                foreach ($subarray as $valor) {
                  echo $valor;
                }
              }
            } else {
              echo "O valor retornado não é um array.";
            }
            ?>
          </span>
        </div>

      </div>
</body>

</html>