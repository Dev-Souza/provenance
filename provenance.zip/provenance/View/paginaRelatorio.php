<?php
require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';
$pedidoDAO = new PedidoDAO();

//Descobrindo o total do faturamento
$totalFaturamento = $pedidoDAO->totalFaturamento();

//Descobrindo meus gastos
$totalGasto = $pedidoDAO->totalGasto();

//Descobrindo produtos mais vendidos
$prodMaisVendido = $pedidoDAO->prodMaisVendido();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios</title>
    <link rel="stylesheet" href="../css/relatorio.css">
    <style>
        .center-text {
            text-align: center;
        }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Dia', 'Entradas', 'Saídas'],
                ['Setembro', 1000, 400],
                ['Outubro', 1170, 460],
                ['Novembro', 660, 1120],
                ['Dezembro', 1030, 540]
            ]);

            var options = {
                title: 'Performance Provenance',
                titleTextStyle: {
                    fontSize: 18, // Ajuste o tamanho conforme necessário
                },
                hAxis: {
                    title: 'Meses',
                    titleTextStyle: {
                        color: '#333'
                    }
                },
                vAxis: {
                    minValue: 0
                },
                series: {
                    0: {
                        color: 'green'
                    }, // Cor para a série "Entradas"
                    1: {
                        color: 'red'
                    } // Cor para a série "Saídas"
                }
            };

            var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
    </script>
    <!-- GRÁFICO DE ROSCA -->
    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Faturamentos e Gastos', 'Quantidade'],
                ['Faturamentos', <?php
                                    if (is_array($totalFaturamento)) {
                                        foreach ($totalFaturamento as $subarray) {
                                            foreach ($subarray as $valor) {
                                                echo $valor;
                                            }
                                        }
                                    } else {
                                        echo "O valor retornado não é um array.";
                                    }
                                    ?>],
                ['Gastos', <?php
                            if (is_array($totalGasto)) {
                                foreach ($totalGasto as $subarray) {
                                    foreach ($subarray as $valor) {
                                        echo $valor;
                                    }
                                }
                            } else {
                                echo "O valor retornado não é um array.";
                            }
                            ?>]
            ]);

            var options = {
                title: 'Meus Faturamentos e Gastos',
                titleTextStyle: {
                    fontSize: 18, // Ajuste o tamanho conforme necessário
                },
                pieHole: 0.4,
                slices: {
                    0: {
                        color: '#00b33c'
                    },
                    1: {
                        color: 'red'
                    }
                },
                legend: 'none',
            };

            var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
            chart.draw(data, options);
        }
    </script>
    <!-- GRÁFICO TABELA -->
    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['table']
        });
        google.charts.setOnLoadCallback(drawTable);

        function drawTable() {
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Nome');
            data.addColumn('number', 'Quantidade');
            data.addColumn('string', 'Total vendido'); // Mudança para 'string' para exibir R$

            <?php
            if (is_array($prodMaisVendido)) {
                foreach ($prodMaisVendido as $subarray) {
                    echo "data.addRow(['" . $subarray['nomeProduto'] . "', " . $subarray['totalQuantidade'] . ", 'R$" . number_format($subarray['totalPreco'], 2, ',', '.') . "']);";
                }
            } else {
                echo "// O valor retornado não é um array.";
            }
            ?>

            var table = new google.visualization.Table(document.getElementById('table_div'));

            table.draw(data, {
                showRowNumber: true,
                width: '100%',
                height: '300px',
                cssClassNames: {
                    tableCell: 'center-text', // Classe CSS personalizada para centralizar o conteúdo
                    headerCell: 'center-text'
                }
            });
        }
    </script>
</head>

<body>
    <div class="title-top">
        <h2 class="title_list">Relatórios</h2>
        <hr>
    </div>
    <div class="container_principal">
        <div class="chart_area">
            <div id="chart_div" style="width: 100%; height: 400px;"></div>
        </div>
        <div class="my_charts">
            <div class="chart_rosca">
                <div id="donutchart" style="width: 100%; height: 310px;"></div>
            </div>
            <div class="chart_table">
                <div id="table_div"></div>
            </div>
        </div>
    </div>
</body>

</html>