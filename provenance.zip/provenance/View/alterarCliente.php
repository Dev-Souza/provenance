<?php
session_start();
$idUsuario = "";
//Valida se houve login no sistema
if (!isset($_SESSION["idUsuario"])) {
    header("location:../index.php?msg=Acesso Indevido!");
}

//Testa se foi enviado um GET com idUsuario a ser alterado
if (isset($_GET["idUsuario"])) {
    $idUsuario = $_GET["idUsuario"];
} else {
    //Se um GET não foi passado, significa que a 
    //ALTERACAO é do próprio usuário logado. Usa o da SESSION
    $idUsuario = $_SESSION["idUsuario"];
}

$idUsuarioLogin = $_SESSION["idUsuario"];
$perfil_idPerfilLogin = $_SESSION["Perfil_idPerfil"];

require_once '../Model/usuarioDTO.php';
require_once '../Model/usuarioDAO.php';

$usuarioDAO = new UsuarioDAO();
$perfis = $usuarioDAO->listarPerfil();
$retorno = $usuarioDAO->PesquisarUsuarioPorId($idUsuario);
if (!$retorno) {
    if ($perfil_idPerfilLogin == 1) {
        header("location:listarUsuario.php?msg=Usuário não localizado!");
    } else {
        header("location:index.php?msg=Usuário não localizado!");
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Cadastro de Cliente</title>
    <link rel="stylesheet" href="../css/alterarUsuario.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <!-- DOBRA CABEÇALHO -->
    <header class="main_header" id="main_header">
        <div class="main_header_content">
            <img src="../img/novaLogo.png" alt="Bem vindo ao projeto Provenance">
            <nav class="main_header_content_menu">
                <ul>
                    <li><a href="abrirPedido.php">Voltar</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <!--FIM DOBRA CABEÇALHO-->
    <div class="container_principal">
        <div class="titlle_top">
            <h2>Alterar Usuário</h2>
        </div>
        <div class="content_alterar_usuario">
            <form name="alterarUsuario" id="alterarCliente" action="../Control/alterarClienteController.php" method="POST" enctype="multipart/form-data">
                <div class="form_alterar_usuario">
                    <div class="input_group">
                        <input type="hidden" name="idUsuario" value="<?php echo $retorno["idUsuario"]; ?>">
                        <label for="nomeUsuario">Nome Completo</label><br>
                        <input type="text" name="nomeUsuario" value="<?php echo $retorno["nomeUsuario"]; ?>" required>
                    </div>
                    <div class="input_group">
                    <label for="genero">Gênero</label><br>
                        <select name="genero">
                            <?php
                            if ($retorno["genero"] == "Masculino") {
                                echo '<option value="Masculino" selected=selected>Masculino</option>';
                            } else {
                                echo '<option value="Masculino">Masculino</option>';
                            }
                            if ($retorno["genero"] == "Feminimo") {
                                echo '<option value="Feminimo" selected=selected>Feminimo</option>';
                            } else {
                                echo '<option value="Feminimo">Feminimo</option>';
                            }
                            if ($retorno["genero"] == "Outro") {
                                echo '<option value="Outro" selected=selected>Outro</option>';
                            } else {
                                echo '<option value="Outro">Outro</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="input_group">
                        <label for="dtNascimento">Data de Nascimento</label><br>
                        <input type="date" name="dtNascimento" value="<?php echo $retorno["dtNascimento"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="cpf">CPF</label><br>
                        <input type="cpf" name="cpf" value="<?php echo $retorno["cpf"]; ?>">
                    </div>
                    <div class="input_group">
                        <label for="email">Email</label><br>
                        <input type="email" name="email" value="<?php echo $retorno["email"]; ?>" required> <br>
                    </div>

                    <?php
                    if ($perfil_idPerfilLogin != 1) {
                        echo '<input type="hidden" name="Perfil_idPerfil" 
                value="' . $retorno["Perfil_idPerfil"] . '">';
                        echo '<input type="hidden" name="situacaoUsuario" 
                value="' . $retorno["situacaoUsuario"] . '">';
                    } else {
                        echo '<div class="input_group">';
                        echo '<label for="situacaoUsuario">Situação</label> <br>
                        <select name="situacaoUsuario">';

                        if ($retorno["situacaoUsuario"] == "Ativo") {
                            echo '<option value="Ativo" selected=selected>Ativo</option>';
                        } else {
                            echo '<option value="Ativo">Ativo</option>';
                        }
                        if ($retorno["situacaoUsuario"] == "Inativo") {
                            echo '<option value="Inativo" selected=selected>Inativo</option>';
                        } else {
                            echo '<option value="Inativo">Inativo</option>';
                        }
                    }

                    ?>
                    <br>
                    <input type="submit" onclick="atomicidade(event)" value="Salvar Alteração" class="btn_alteracao">
                </div>
            </form>
        </div>
    </div>
    <script>
        function atomicidade(event) {
            event.preventDefault(); // Impede o envio padrão do formulário
            Swal.fire({
                title: "Alterado com sucesso!",
                text: "Informações de produto foram alteradas com sucesso",
                icon: "success"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Submeter o formulário
                    document.getElementById("alterarCliente").submit();
                }
            });
        }
    </script>
</body>

</html>