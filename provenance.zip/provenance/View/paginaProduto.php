<?php
//Valida se houve login no sistema
if (isset($_SESSION["idUsuario"])) {
    //Passa o perfil de login para uma variável
    //O perfil de Administrador permite mudar o Perfil do Usuário
    //e a Situação 
    $perfil_idPerfilLogin = $_SESSION["Perfil_idPerfil"];
}

//incorpora o Produto DTO e DAO para poder carregar a lista de Produto 
require_once "../Model/produtoDTO.php";
require_once "../Model/produtoDAO.php";
$produtoDAO = new ProdutoDAO();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produto</title>
    <link rel="stylesheet" href="../css/paginaProduto.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="titlle_top">
        <h2>Cadastrar Produto</h2>
    </div>
    <hr>
    <div class="content_cadastrar_produto">
        <form action="../Control/cadastrarProdutoController.php" method="POST" name="cadastrarProduto" id="cadastrarProduto" enctype="multipart/form-data">
            <div class="form_cadastrar_produto">
                <div class="input_group">
                    <label for="codigoBarra">Código de Barra</label><br>
                    <input type="number" name="codigoBarra" placeholder="Digite o código de barra">
                </div>
                <div class="input_group">
                    <label for="nomeProduto">Nome do Produto</label><br>
                    <input type="text" name="nomeProduto" id="nomeProduto" placeholder="Digite o nome do produto">
                </div>
                <div class="input_group">
                    <label for="dtValidade">Data de Validade</label><br>
                    <input type="date" name="dtValidade">
                </div>
                <div class="input_group">
                    <label for="qtdeProduto">Quantidade</label><br>
                    <input type="number" name="qtdeProduto" placeholder="Digite a quantidade">
                </div>
                <div class="input_group">
                    <label for="peso">Peso</label><br>
                    <input type="number" name="peso" placeholder="Digite o peso do produto">
                </div>
                <div class="input_group">
                    <label for="receita">Tem Receita?</label><br>
                    <select name="receita" id="receita">
                        <option value="#">Selecione uma opção</option>
                        <option value="Sim">Sim</option>
                        <option value="Não">Não</option>
                    </select>
                </div>
                <div class="input_group">
                    <label for="remedioControlado">É Remédio Controlado?</label><br>
                    <select name="remedioControlado" id="remedioControlado">
                        <option value="#">Selecione uma opção</option>
                        <option value="Sim">Sim</option>
                        <option value="Não">Não</option>
                    </select>
                </div>
                <div class="input_group">
                    <label for="precoCompra">Preço de Compra</label><br>
                    <input type="number" name="precoCompra" placeholder="Digite o preço de compra">
                </div>
                <div class="input_group">
                    <label for="precoVenda">Preço de Venda</label><br>
                    <input type="number" name="precoVenda" placeholder="Digite o preço de venda">
                </div>
                <div class="input_group">
                    <label for="imgProduto">Imagem do Produto</label><br>
                    <input type="file" name="imgProduto" accept="image/*">
                </div>
                <div class="input_group">
                    <label for="dtEntrada">Data de Entrada</label><br>
                    <input type="date" name="dtEntrada">
                </div>
                <div class="input_group">
                    <label for="categoria">Categoria</label><br>
                    <select name="categoria" id="categoria">
                        <option value="#">Selecione uma opção</option>
                        <option value="Acessórios">Acessórios</option>
                        <option value="Analgésicos">Analgésicos</option>
                        <option value="Antialérgicos">Antialérgicos</option>
                        <option value="Antibióticos">Antibióticos</option>
                        <option value="Antidepressivos">Antidepressivos</option>
                        <option value="Antidiarreicos">Antidiarreicos</option>
                        <option value="Antitússicos">Antitússicos</option>
                        <option value="Antiácidos">Antiácidos</option>
                        <option value="Bem-Estar">Bem-Estar</option>
                        <option value="Hidratantes">Hidratantes</option>
                        <option value="Higiene">Higiene</option>
                        <option value="Infantil">Infantil</option>
                        <option value="Oftálmicos">Oftálmicos</option>
                        <option value="Suplementos">Suplementos</option>
                        <option value="Vitaminas">Vitaminas</option>
                    </select>
                </div>
                <div class="input_group">
                    <label for="prateleira">Prateleira</label><br>
                    <input type="text" name="prateleira" id="prateleira" placeholder="Em qual prateleira o produto está?">
                </div>
                <div class="input_group">
                    <label for="estoqueMinimo">Estoque Mínimo</label><br>
                    <input type="text" name="estoqueMinimo" id="estoqueMinimo" placeholder="Digite o estoque mínimo">
                </div>
                <input type="submit" class="btn-cadastrar" onclick="atomicidade(event)" id="btnCadastrar" value="Cadastrar Produto">
            </div>
        </form>
    </div>
</body>
<script>
    function atomicidade(event) {
        event.preventDefault(); // Impede o envio padrão do formulário
        Swal.fire({
            title: "Cadastrado com sucesso!",
            text: "Os dados de produto foram cadastrados",
            icon: "success"
        }).then((result) => {
            if (result.isConfirmed) {
                // Submeter o formulário
                document.getElementById("cadastrarProduto").submit();
            }
        });
    }
</script>

</html>