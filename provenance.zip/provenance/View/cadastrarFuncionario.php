<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Funcionário</title>
    <link rel="stylesheet" href="../css/cadastrarFuncionario.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="main-cadastrar">
        <div class="left-cadastrar">
            <h1>Cadastre aqui!<br>Que seje uma boa experiência!</h1>
            <img src="../img/logisticAnimada.svg" class="left-cadastrar-image" alt="Pessoa levantando uma caixa">
        </div>
        <div class="right-cadastrar">
            <div class="card-cadastrar">
                <h1>Cadastrar Funcionário</h1>
                <form action="../Control/cadastrarFuncionarioController.php" method="POST" name="cadastrarUsuario" enctype="multipart/form-data" id="cadastrarFuncionario">
                    <div class="textfield">
                        <label for="nomeUsuario">Nome completo</label>
                        <input type="text" name="nomeUsuario" id="nomeUsuario" placeholder="Digite o nome completo" required>
                    </div>
                    <div class="textfield">
                        <label for="fotoUsuario">Foto</label>
                        <input type="file" name="fotoUsuario" id="fotoUsuario">
                    </div>
                    <div class="textfield">
                        <label for="dtNascimento">Data de Nascimento</label>
                        <input type="date" name="dtNascimento" id="dtNascimento">
                    </div>
                    <div class="textfield">
                        <label for="cpf">CPF</label>
                        <input type="text" name="cpf" id="cpf" placeholder="Digite o CPF">
                    </div>
                    <div class="textfield">
                        <label for="senha">Gênero</label>
                        <select name="genero" id="genero">
                            <option value="#">Selecione uma opção</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Feminimo">Feminino</option>
                            <option value="Outro">Outro</option>
                        </select>
                    </div>
                    <div class="textfield">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Digite o email" required>
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" id="senha" placeholder="Digite a senha" required>
                    </div>
                    <div class="textfield">
                    <label for="Perfil_idPerfil">Cargo</label>
                    <select name="Perfil_idPerfil" id="Perfil_idPerfil">
                        <option value="#">Selecione um cargo</option>
                        <option value="2">Farmacêutico</option>
                        <option value="3">Atendente</option>
                    </select>
                    </div>
                    <button class="btn-cadastrar" onclick="atomicidade(event)">Cadastrar</button>
                </form>
            </div>
        </div>
    </div>
    <script>
    function atomicidade(event) {
        event.preventDefault(); // Impede o envio padrão do formulário
        Swal.fire({
            title: "Cadastrado com sucesso!",
            text: "Os dados informados foram cadastrados",
            icon: "success"
        }).then((result) => {
            if (result.isConfirmed) {
                // Submeter o formulário
                document.getElementById("cadastrarFuncionario").submit();
            }
        });
    }
</script>
</body>

</html>