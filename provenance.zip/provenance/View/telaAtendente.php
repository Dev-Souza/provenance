<?php
session_start();
$idUsuario = "";
//Valida se houve login no sistema
if (!isset($_SESSION["idUsuario"])) {
    header("location:../index.php?msg=Acesso Indevido!");
}

//Testa se foi enviado um GET com idUsuario a ser alterado
if (isset($_GET["idUsuario"])) {
    $idUsuario = $_GET["idUsuario"];
} else {
    //Se um GET não foi passado, significa que a 
    //ALTERACAO é do próprio usuário logado. Usa o da SESSION
    $idUsuario = $_SESSION["idUsuario"];
}

$idUsuarioLogin = $_SESSION["idUsuario"];
$perfil_idPerfilLogin = $_SESSION["Perfil_idPerfil"];

require_once '../Model/usuarioDTO.php';
require_once '../Model/usuarioDAO.php';

$usuarioDAO = new UsuarioDAO();
$perfis = $usuarioDAO->listarPerfil();
$linha = $usuarioDAO->PesquisarUsuarioPorId($idUsuario);
require_once '../Model/produtoDTO.php';
require_once '../Model/produtoDAO.php';
$produtoDAO = new ProdutoDAO();
$pesquisar = '';
if (isset($_GET['pesquisar'])) {
    $pesquisar = $_GET['pesquisar'];
    // $retorno = $produtoDAO->pesquisarProdutoFiltro($pesquisar);
} else {

}

$retorno = $produtoDAO->pesquisarProduto($pesquisar);

//retorno = $produtoDAO->pesquisarProduto();

require_once '../Model/pedidoDTO.php';
require_once '../Model/pedidoDAO.php';
$pedidoDAO = new PedidoDAO();
$pedidoAberto = $_GET['idPedido'];
$itensCarrinho = $pedidoDAO->retornarCarrinhoPorId($pedidoAberto);
//$pedidoAberto = $pedidoDAO->PesquisarPedidoPorId($idUsuario);
// if (!empty($_GET['search'])) {
//     $data = $_GET['search'];
//     $sql = "SELECT * FROM produto WHERE nomeProduto LIKE '%$data%' OR categoria LIKE '%$data%' OR codigoBarra LIKE '%$data%' ORDER BY nomeProduto DESC";
// } else {
//     $sql = "SELECT * FROM produto ORDER BY nomeProduto DESC";
// }
//$result = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela Atendente</title>
    <!-- LINK CSS -->
    <link rel="stylesheet" href="../css/telaAtendente.css">
    <!-- ICONS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <!-- HEADER -->
    <header>
        <div class="nav container">
            <a href="#" class="logo">Prov<img src="../img/logoProvenance.png" alt="">nance </a>
            <!-- Cart ICON -->
            <div>
                <a href="abrirPedido.php">Abrir Outro Pedido</a>
                <i class="bi bi-cart size-cart" id="cart-icon"></i>
            </div>
            <!-- Cart -->
            <div class="cart">
                <h2 class="card-title">Seu Carrinho</h2>
                <!-- Conteúdo carrinho -->
                <?php
                $totalPedido = 0.00;
                if (!empty($itensCarrinho)) {
                    foreach ($itensCarrinho as $itens) {
                        if (isset($itens) && $itens['situacaoPedido'] == 'Aberto') {
                            $totalPedido = $itens["valorTotal"];
                            echo '<div class="cart-content">';
                            echo '<img src="../uploadArq/' . $itens['imgProduto'] . '" alt="imagem do produto" class="cart-img">';
                            echo '      <div class="datail-box">
                                            <div class="cart-product-title">' . $itens['nomeProduto'] . '</div>
                                            <div class="cart-price">' . $itens['precoUnitario'] . '</div>
                                            <div class="quantidade">' . $itens['qtdeItem'] . '</div>
                                        </div>
                                        <a href="../Control/excluirCarrinhoController.php?idPedido=' . $itens['Pedido_idPedido'] . '&idProduto=' . $itens['Produto_idProduto'] . '&idUsuario=' . $linha['idUsuario'] . '&precoTotalItem='.$itens['precoTotalItem'].'&qtdeItem='.$itens['qtdeItem'].'"  onclick="return confirm(' . "'Tem certeza que deseja tirar este item do carrinho?'" . ')"><i class="bi bi-trash-fill"></i></a>
                                        
                                  </div>';
                        }

                    }
                    //É do JavaScript para remover item do carrinho
                    //cart-remove 
                

                }
                ?>
                <!-- Total -->
                <div class="total">
                    <div class="total-title">Total</div>
                    <div class="total-price">R$
                        <?php echo $totalPedido; ?>
                    </div>
                </div>
                <!-- Botão comprar -->
                <?php
                echo '<a href="../Control/pagarController.php?idPedido='.$pedidoAberto.'&idUsuario='.$linha['idUsuario'].'&valorTotal='.$totalPedido.'&precoUnitario='.$itens['precoUnitario'].'">
                    <button type="button" class="btn-buy">Pagar</button>
                </a>
                <!-- Cart Close-->
                <i class="bi bi-x-lg" id="close-cart"></i>';
                ?>
            </div>
        </div>
    </header>

    <!-- SHOP -->
    <section class="shop container">
        <h1 class="nomeCliente"><label for="nomeCliente">Nome Cliente:</label>
            <?php echo $linha["nomeUsuario"]; ?>
        </h1>
        <h2 class="section-title">Produtos em Estoque</h2>
        <!-- Butão de pesquisar produto -->
        <form
            action="telaAtendente.php?idUsuario=<?php echo $idUsuario; ?>&idPedido=<?php echo $pedidoAberto; ?>&pesquisar=<?php echo $pesquisar; ?>"
            method="POST">
            <div class="box-search">

                <input type="text" name="pesquisar" id="pesquisar" class="form-control w-25"
                    placeholder="Pesquisar produto">
                <input type="submit" class="btn btn-primary">
                <!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                        class="bi bi-search" viewBox="0 0 16 16">
                        <path
                            d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                    </svg> -->


            </div>
        </form>
        <!-- Conteúdo -->
        <div class="shop-content">
            <!-- Caixa 1 -->
            <?php
            if (!empty($retorno)) {
                foreach ($retorno as $linha) {
                    if ($linha["qtdeProduto"] >= 1) {
                        echo '<form name="form' . $pedidoAberto . $linha["idProduto"] . '" action="../Control/incluirItemCarrinhoController.php" method="POST">';
                        echo '<input type="hidden" name="idPedido" value="' . $pedidoAberto . '"/>';
                        echo '<input type="hidden" name="idProduto" value="' . $linha['idProduto'] . '"/>';
                        echo '<input type="hidden" name="precoVenda" value="' .
                            $linha['precoVenda'] . '"/>';
                        echo '<input type="hidden" name="qtd" value="1"/>';
                        echo '<input type="hidden" name="idUsuario" value="' .
                            $idUsuario . '"/>';
                        echo '<div class="product-box">';

                        echo '<img src="../uploadArq/' . $linha["imgProduto"] . '" class="product-img"/>';
                        echo '<h2 class="product-title"/>' . $linha["nomeProduto"] . '</h2>';
                        echo '<span class="price">R$' . $linha["precoVenda"] . '</span>';
                        echo '<input class="bi bi-cart add-cart" type="submit" value="Adicionar ao carrinho"/>';
                        //$x = "?idPedido=$pedidoAberto&idProduto=".$linha['idProduto'].'&precoVenda='.$linha['precoVenda'].'&qtd=1';
                        //$x = $pedidoAberto."|".$linha["idProduto"].'|'.$linha['precoVenda'].'|1';
                        //echo '<a href="../Control/incluirItemCarrinhoController.php?x='.$x.'"><i class="bi bi-cart add-cart"></i></a>';
                        //echo '<a href="../Control/incluirItemCarrinhoController.php?idPedido=1&idProduto=1&$&precoVenda=12.00&qtd=1"><i class="bi bi-cart add-cart"></i></a>';
                        //
                        echo '</div></form>';
                    }
                }
            } else {
                echo "<hr>*** NENHUM PRODUTO LOCALIZADO ***<hr>";
            }
            ?>
        </div>
    </section>
    <!-- Link JS -->
    <script src="../js/telaAtendente.js"></script>
    <script>
        var search = document.getElementById('pesquisar');

        search.addEventListener("keydown", function (event) {
            if (event.key === "Enter") {
                searchData();
            }
        });
        function searchData() {
            window.location = "telaAtendente.php?search=" + search.value;

        }
    </script>
</body>

</html>