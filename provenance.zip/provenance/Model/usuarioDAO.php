<?php
//conexão com BD
require_once "conexao.php";
require_once "usuarioDTO.php";
class UsuarioDAO
{

    public $pdo = null;
    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }
    // INSERT
    public function salvarUsuario(UsuarioDTO $usuarioDTO)
    {
        try {
            $sql = "INSERT INTO `Usuario`(`nomeUsuario`, `dtNascimento`, `fotoUsuario`, `cpf`, `genero`, `email`, `senha`, `situacaoUsuario`, `Perfil_idPerfil`) 
            VALUES (?,?,?,?,?,?,?,?,?)";
            $stmt = $this->pdo->prepare($sql);

            $nomeUsuario = $usuarioDTO->getNomeUsuario();
            $dtNascimento = $usuarioDTO->getDtNascimento();
            $fotoUsuario = $usuarioDTO->getFotoUsuario();
            $cpf = $usuarioDTO->getCpf();
            $genero = $usuarioDTO->getGenero();
            $email = $usuarioDTO->getEmail();
            $senha = $usuarioDTO->getSenha();
            $situacaoUsuario = $usuarioDTO->getSituacaoUsuario();
            $Perfil_idPerfil = $usuarioDTO->getPerfil_idPerfil();

            $stmt->bindValue(1, $nomeUsuario);
            $stmt->bindValue(2, $dtNascimento);
            $stmt->bindValue(3, $fotoUsuario);
            $stmt->bindValue(4, $cpf);
            $stmt->bindValue(5, $genero);
            $stmt->bindValue(6, $email);
            $stmt->bindValue(7, $senha);
            $stmt->bindValue(8, $situacaoUsuario);
            $stmt->bindValue(9, $Perfil_idPerfil);

            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Método alterarUsuario
    // UPDATE
    public function alterarUsuario(UsuarioDTO $usuarioDTO)
    {
        try {
            $sql = "UPDATE `Usuario` SET `nomeUsuario`=?,
        `fotoUsuario`=?,`dtNascimento`=?,
        `cpf`=?,`email`=?,
        `senha`=?,`situacaoUsuario`=?,`Perfil_idPerfil`=? 
        WHERE `idUsuario`= ?";
            $stmt = $this->pdo->prepare($sql);
            $idUsuario = $usuarioDTO->getIdUsuario();
            $nomeUsuario = $usuarioDTO->getNomeUsuario();
            $fotoUsuario = $usuarioDTO->getFotoUsuario();
            $dtNascimento = $usuarioDTO->getDtNascimento();
            $cpf = $usuarioDTO->getCpf();
            $email = $usuarioDTO->getEmail();
            $senha = $usuarioDTO->getSenha();
            $situacaoUsuario = $usuarioDTO->getSituacaoUsuario();
            $Perfil_idPerfil = $usuarioDTO->getPerfil_idPerfil();

            $stmt->bindValue(1, $nomeUsuario);
            $stmt->bindValue(2, $fotoUsuario);
            $stmt->bindValue(3, $dtNascimento);
            $stmt->bindValue(4, $cpf);
            $stmt->bindValue(5, $email);
            $stmt->bindValue(6, $senha);
            $stmt->bindValue(7, $situacaoUsuario);
            $stmt->bindValue(8, $Perfil_idPerfil);
            $stmt->bindValue(9, $idUsuario);

            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //fim médodo alterarUsuario

    //Método excluirUsuario
    public function excluirUsuario($idUsuario)
    {
        try {
            $sql = "DELETE FROM `usuario` 
        WHERE `idUsuario` = '{$idUsuario}';";

            $stmt = $this->pdo->prepare($sql);

            $retorno = $stmt->execute();

            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim excluirUsuario

    // método validarLogin
    public function validarLogin($email, $senha)
    {
        try {
            $sql = "SELECT * FROM `usuario` 
        WHERE `email` = '{$email}' AND 
        `senha` = '{$senha}';";

            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    // fim validarLogin

    //LISTAR PERFIL
    public function listarPerfil()
    {
        try {
            $sql = "SELECT * FROM Perfil ";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();

            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //FIM LISTARPERIL

    //PesquisarUsuario
    public function PesquisarUsuario()
    {
        try {
            $sql = "SELECT u.*, p.*
        FROM `Usuario` u
        INNER JOIN Perfil p ON u.`Perfil_idPerfil` = p.idPerfil";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarUsuario

    //PesquisarUsuarioPorId
    public function PesquisarUsuarioPorId($idUsuario)
    {
        try {
            $sql = "SELECT u.*, p.nomePerfil 
        FROM `Usuario` u
        INNER JOIN Perfil p ON u.`Perfil_idPerfil` = p.idPerfil
        WHERE u.idUsuario = '{$idUsuario}'";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarUsuarioPorId

}
