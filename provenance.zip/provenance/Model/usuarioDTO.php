<?php 
    class UsuarioDTO{
        private $idUsuario;
        private $nomeUsuario;
        private $dtNascimento;
        private $fotoUsuario;
        private $cpf; 
        private $genero;
        private $email;
        private $senha;
        private $token;
        private $situacaoUsuario;
        private $Perfil_idPerfil;

        // Métodos setters
        public function setIdUsuario($idUsuario){
            $this->idUsuario = $idUsuario;
        }
        public function setNomeUsuario($nomeUsuario){
            $this->nomeUsuario = $nomeUsuario;
        }
        public function setDtNascimento($dtNascimento){
            $this->dtNascimento = $dtNascimento;
        }
        public function setFotoUsuario($fotoUsuario){
            $this->fotoUsuario = $fotoUsuario;
        }
        public function setCpf($cpf){
            $this->cpf = $cpf;
        }
        public function setGenero($genero){
            $this->genero = $genero;
        }
        public function setEmail($email){
            $this->email = $email;
        }
        public function setSenha($senha){
            $this->senha = $senha;
        }
        public function setToken($token){
            $this->token = $token;
        }
        public function setSituacaoUsuario($situacaoUsuario){
            $this->situacaoUsuario = $situacaoUsuario;
        }
        public function setPerfil_idPerfil($Perfil_idPerfil){
            $this->Perfil_idPerfil = $Perfil_idPerfil;
        }
        
        // Métodos getters
        public function getIdUsuario(){
            return $this->idUsuario;
        }
        public function getNomeUsuario(){
            return $this->nomeUsuario;
        }
        public function getDtNascimento(){
            return $this->dtNascimento;
        }
        public function getFotoUsuario(){
            return $this->fotoUsuario;
        }
        public function getCpf(){
            return $this->cpf;
        }
        public function getGenero(){
            return $this->genero;
        }
        public function getEmail(){
            return $this->email;
        }
        public function getSenha(){
            return $this->senha;
        }
        public function getToken(){
            return $this->token;
        }
        public function getSituacaoUsuario(){
            return $this->situacaoUsuario;
        }
        public function getPerfil_idPerfil(){
            return $this->Perfil_idPerfil;
        }
    }

    
?>