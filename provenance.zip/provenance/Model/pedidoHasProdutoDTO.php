<?php 
    class UsuarioDTO{
        private $Pedido_idPedido;
        private $Produto_idProduto;
        private $qtdeItem;
        private $precoUnitario;
        private $precoTotalItem; 

        // Métodos setters
        public function setPedido_idPedido($Pedido_idPedido){
            $this->Pedido_idPedido = $Pedido_idPedido;
        }
        public function setProduto_idProduto($Produto_idProduto){
            $this->Produto_idProduto = $Produto_idProduto;
        }
        public function setQtdeItem($qtdeItem){
            $this->qtdeItem = $qtdeItem;
        }
        public function setPrecoUnitario($precoUnitario ){
            $this->precoUnitario = $precoUnitario;
        }
        public function setPrecoTotalItem($precoTotalItem){
            $this->precoTotalItem = $precoTotalItem;
        }
        
        // Métodos getters
        public function getPedido_idPedido(){
            return $this->Pedido_idPedido;
        }
        public function getProduto_idProduto(){
            return $this->Produto_idProduto;
        }
        public function getQtdeItem(){
            return $this->qtdeItem;
        }
        public function getPrecoUnitario(){
            return $this->precoUnitario;
        }
        public function getPrecoTotalItem(){
            return $this->precoTotalItem;
        }
    }

    
?>