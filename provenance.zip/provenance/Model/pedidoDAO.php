<?php
//conexão com BD
require_once "conexao.php";
require_once "pedidoDTO.php";
class PedidoDAO
{

    public $pdo = null;
    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }
    // INSERT
    public function incluirPedidoAberto($Usuario_idUsuario, $dtPedido)
    {
        try {
            $sql = "INSERT INTO `pedido` (`idPedido`, `dtPedido`, `valorTotal`, `valorPago`, `valorDesconto`, `situacaoPedido`, `descricao`, `Usuario_idUsuario`) 
            VALUES (NULL, '{$dtPedido}', '0.00', '0.00', '0.00', 'Aberto', NULL, '{$Usuario_idUsuario}');";
            $stmt = $this->pdo->prepare($sql);

            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Método alterarPedido
    // UPDATE
    public function alterarPedido(PedidoDTO $pedidoDTO)
    {
        try {
            $sql = "UPDATE `pedido` SET `dtPedido`=?,`valorTotal`=?,`valorPago`=?,`valorDesconto`=?,`situacaoPedido`=?,`descricao`=?,`Usuario_idUsuario`=? 
            WHERE `idPedido` = ?";
            $stmt = $this->pdo->prepare($sql);
            $idPedido = $pedidoDTO->getIdPedido();
            $dtPedido = $pedidoDTO->getDtPedido();
            $valorTotal = $pedidoDTO->getValorTotal();
            $valorPago = $pedidoDTO->getValorPago();
            $valorDesconto = $pedidoDTO->getValorDesconto();
            $situacaoPedido = $pedidoDTO->getSituacaoPedido();
            $descricao = $pedidoDTO->getDescricao();
            $Usuario_idUsuario = $pedidoDTO->getUsuario_idUsuario();

            $stmt->bindValue(1, $dtPedido);
            $stmt->bindValue(2, $valorTotal);
            $stmt->bindValue(3, $valorPago);
            $stmt->bindValue(4, $valorDesconto);
            $stmt->bindValue(5, $situacaoPedido);
            $stmt->bindValue(6, $descricao);
            $stmt->bindValue(7, $Usuario_idUsuario);
            $stmt->bindValue(8, $idPedido);

            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //fim médodo alterarPedido

    //Método excluirPedido
    public function excluirPedido($idPedido)
    {
        try {
            $sql = "DELETE FROM `pedido` 
            WHERE `idPedido` = '{$idPedido}';";

            $stmt = $this->pdo->prepare($sql);

            $retorno = $stmt->execute();

            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim excluirPedido


    //PesquisarPedido
    public function pesquisarPedido()
    {
        try {
            $sql = "SELECT * FROM `pedido`";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarPedido

    //PesquisarPedidoPorId
    public function PesquisarPedidoPorId($idPedido)
    {
        try {
            $sql = "SELECT * FROM `pedido` WHERE idPedido = '{$idPedido}'";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarPedidoPorId
    //PesquisarPedidoPorId
    public function buscarPedidoAberto($idUsuario)
    {
        try {
            $sql = "SELECT p.*, u.* FROM `pedido` p
            INNER JOIN usuario u ON p.Usuario_idUsuario = u.idUsuario
            WHERE Usuario_idUsuario = '{$idUsuario}' AND situacaoPedido = 'Aberto'";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarPedidoPorId
    public function buscarItensPedido($idPedido)
    {
        try {
            $sql = "SELECT p.*, pr.*, i.* FROM `pedido` p 
            INNER JOIN pedido_has_produto i ON p.idPedido = i.Pedido_idPedido
            INNER JOIN produto pr ON i.Produto_idProduto = pr.idProduto
            WHERE idPedido = '{$idPedido}";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarPedidoPorId

    //Pesquisar Pedido
    public function pesquisarPedidoInner()
    {
        try {
            $sql = "SELECT p.*, u.nomeUsuario FROM pedido p 
            INNER JOIN usuario u ON u.idUsuario = p.Usuario_idUsuario;";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }


    public function incluirItemCarrinho($idPedido, $idProduto, $precoVenda, $qtd)
    {
        $qtd = (float) $qtd;
        $pedidoAberto = $idPedido;
        $precoUnitario = (float) $precoVenda;
        $precoTotalItem = $precoUnitario * $qtd;


        //Pesquisar se o item já foi incluido.
        try {
            $sql = "SELECT * FROM `pedido_has_produto` 
            WHERE `Pedido_idPedido` ='{$pedidoAberto}' AND `Produto_idProduto` = '{$idProduto}'";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            if (empty($retorno)) {
                //Caso não exista o produto no carrinho, INSERE.
                $sql = "INSERT INTO `pedido_has_produto`(`Pedido_idPedido`, `Produto_idProduto`, `qtdeItem`, `precoUnitario`, `precoTotalItem`) 
                VALUES ('{$pedidoAberto}','{$idProduto}','{$qtd}','{$precoUnitario}','{$precoTotalItem}')";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute();

                //Atualizar o valor total do pedido
                $sql = "UPDATE `pedido` p SET p.`valorTotal`= (SELECT SUM(i1.precoTotalItem) FROM `pedido_has_produto` i1 WHERE i1.Pedido_idPedido = '{$pedidoAberto}') 
                WHERE p.idPedido ='{$pedidoAberto}';";
                $stmt = $this->pdo->prepare($sql);

                $stmt->execute();
                //$retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                //Altera a quantidade do item no carrinho
                //Caso não exista o produto no carrinho, INSERE.
                $qtd = (float) $retorno['qtdeItem'] + 1.00;
                $precoTotalItem = $precoUnitario * $qtd;
                //$precoUnitario = (float) $retorno['precoUnitario'];
                $sql = "UPDATE `pedido_has_produto` 
                SET `qtdeItem`='{$qtd}',`precoUnitario`= '{$precoUnitario}', `precoTotalItem`='{$precoTotalItem}' 
                WHERE `Pedido_idPedido` ='{$pedidoAberto}' AND `Produto_idProduto` = '{$idProduto}'";
                $stmt = $this->pdo->prepare($sql);

                $stmt->execute();
                //Atualizar o valor total do pedido
                $sql = "UPDATE `pedido` p SET p.`valorTotal`= (SELECT SUM(i1.precoTotalItem) FROM `pedido_has_produto` i1 WHERE i1.Pedido_idPedido = '{$pedidoAberto}') 
                WHERE p.idPedido ='{$pedidoAberto}';";
                $stmt = $this->pdo->prepare($sql);

                $stmt->execute();
                //$retorno = $stmt->fetch(PDO::FETCH_ASSOC); 
            }
            //Diminui 1 no estoque do produto
            $sql = "UPDATE `produto` SET `qtdeProduto`= `qtdeProduto` - 1
                    WHERE `idProduto` = '{$idProduto}'";
            $stmt = $this->pdo->prepare($sql);
            $processoEstoque = $stmt->execute();

            return $processoEstoque;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Pesquisar Pedido
    public function retornarCarrinhoPorId($idPedido)
    {
        try {
            $sql = "SELECT i . * , pr . * , pe . *
            FROM `pedido_has_produto` i
            INNER JOIN produto pr ON i.Produto_idProduto = pr.idProduto
            INNER JOIN pedido pe ON i.Pedido_idPedido = pe.idPedido
            WHERE i.Pedido_idPedido = '{$idPedido}';";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function retornarCarrinhoTotal($idPedido)
    {
        try {
            $sql = "SELECT SUM(i1.precoTotalItem) FROM `pedido_has_produto` i1 WHERE i1.Pedido_idPedido = '{$idPedido}';";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function excluirItemCarrinho($idPedido, $idProduto, $precoTotalItem, $qtd)
    {
        try {


            $sql = "DELETE FROM pedido_has_produto WHERE `Pedido_idPedido` = '{$idPedido}' AND `Produto_idProduto` = '{$idProduto}'";
            $stmt = $this->pdo->prepare($sql);
            $retorno = $stmt->execute();

            //Atualiza o total da venda
            $sql = "UPDATE `pedido` SET `valorTotal`= `valorTotal` - '{$precoTotalItem}' WHERE `idPedido`= '{$idPedido}'";
            $stmt = $this->pdo->prepare($sql);
            $retorno = $stmt->execute();

            //Devolve a quantidade do produto
            $sql = "UPDATE `produto` SET `qtdeProduto`= `qtdeProduto` + '{$qtd}' WHERE `idProduto`='{$idProduto}'";
            $stmt = $this->pdo->prepare($sql);
            $retorno = $stmt->execute();

            return $retorno;
        } catch (PDOException $exc) {

            echo $exc->getMessage();
        }
    }

    //Função fazer pagamento
    //Pesquisar Pedido
    public function fazerPagamento($idPedido, $idUsuario, $valorTotal, $precoUnitario)
    {
        try {
            $sql = "UPDATE `pedido` SET `valorPago`= $valorTotal, `situacaoPedido`='Pago',`Usuario_idUsuario`= $idUsuario WHERE `idPedido` = $idPedido;";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);


            //A partir da compra alimentando a tabela relatórios
            $sql = "INSERT INTO `relatorio`(`qtdeProduto`, `valorEntrada`, `totVendido`, `produtoMaisVendido`, `Pedido_idPedido`) 
            VALUES (
                (SELECT SUM(qtdeItem) FROM pedido_has_produto WHERE Pedido_idPedido = $idPedido),
                '{$valorTotal}', '{$valorTotal}', (SELECT Produto_idProduto FROM pedido_has_produto GROUP BY Produto_idProduto ORDER BY SUM(qtdeItem) DESC LIMIT 1),
                '{$idPedido}'
            )";
            $stmt = $this->pdo->prepare($sql);
            $retorno = $stmt->execute();

            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Total de faturamento
    public function totalFaturamento()
    {
        try {
            $sql = "SELECT SUM(valorPago) FROM `pedido`;";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Total de Gastos
    public function totalGasto()
    {
        try {
            $sql = "SELECT SUM(precoCompra * qtdeProduto) FROM `produto`;";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Produto mais vendido
    public function prodMaisVendido()
    {
        try {
            $sql = "SELECT pr.nomeProduto, SUM(pp.qtdeItem) AS totalQuantidade, SUM(pp.precoTotalItem) AS totalPreco 
                FROM pedido_has_produto pp 
                INNER JOIN produto pr ON pp.Produto_idProduto = pr.idProduto 
                GROUP BY pp.Produto_idProduto, pr.nomeProduto 
                ORDER BY totalQuantidade DESC;"; // Mudança aqui para ordenar pela quantidade vendida
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
}
