<?php
class PedidoDTO
{
    private $idPedido;
    private $dtPedido;
    private $valorTotal;
    private $valorPago;
    private $valorDesconto;
    private $situacaoPedido;
    private $descricao;
    private $Usuario_idUsuario;

    //Métodos setters
    public function setIdPedido($idPedido)
    {
        $this->idPedido = $idPedido;
    }
    public function setDtPedido($dtPedido)
    {
        $this->dtPedido = $dtPedido;
    }
    public function setValorTotal($valorTotal)
    {
        $this->valorTotal = $valorTotal;
    }
    public function setValorPago($valorPago)
    {
        $this->valorPago = $valorPago;
    }
    public function setValorDesconto($valorDesconto)
    {
        $this->valorDesconto = $valorDesconto;
    }
    public function setSituacaoPedido($situacaoPedido)
    {
        $this->situacaoPedido = $situacaoPedido;
    }
    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;
    }
    public function setUsuario_idUsuario($Usuario_idUsuario)
    {
        $this->Usuario_idUsuario = $Usuario_idUsuario;
    }
    
    // Métodos getters
    public function getIdPedido(){
        return $this->idPedido;
    }
    public function getDtPedido(){
        return $this->dtPedido;
    }
    public function getValorTotal(){
        return $this->valorTotal;
    }
    public function getValorPago(){
        return $this->valorPago;
    }
    public function getValorDesconto(){
        return $this->valorDesconto;
    }
    public function getSituacaoPedido(){
        return $this->situacaoPedido;
    }
    public function getDescricao(){
        return $this->descricao;
    }
    public function getUsuario_idUsuario(){
        return $this->Usuario_idUsuario;
    }
}
?>