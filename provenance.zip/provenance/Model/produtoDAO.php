<?php
//conexão com BD
require_once "conexao.php";
require_once "produtoDTO.php";
class ProdutoDAO
{

    public $pdo = null;
    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }
    // INSERT
    public function salvarProduto(ProdutoDTO $produtoDTO)
    {
        try {
            $sql = "INSERT INTO `produto`(`codigoBarra`, `nomeProduto`, `dtValidade`, `qtdeProduto`, `peso`, `receita`, `precoCompra`, `precoVenda`, `remedioControlado`, `imgProduto`, `dtEntrada`, `categoria`, `prateleira`, `estoqueMinimo`) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $this->pdo->prepare($sql);

            $codigoBarra = $produtoDTO->getCodigoBarra();
            $nomeProduto = $produtoDTO->getNomeProduto();
            $dtValidade = $produtoDTO->getDtValidade();
            $qtdeProduto = $produtoDTO->getQtdeProduto();
            $peso = $produtoDTO->getPeso();
            $receita = $produtoDTO->getReceita();
            $precoCompra = $produtoDTO->getPrecoCompra();
            $precoVenda = $produtoDTO->getPrecoVenda();
            $remedioControlado = $produtoDTO->getRemedioControlado();
            $imgProduto = $produtoDTO->getImgProduto();
            $dtEntrada = $produtoDTO->getDtEntrada();
            $categoria = $produtoDTO->getCategoria();
            $prateleira = $produtoDTO->getPrateleira();
            $estoqueMinimo = $produtoDTO->getEstoqueMinimo();

            $stmt->bindValue(1, $codigoBarra);
            $stmt->bindValue(2, $nomeProduto);
            $stmt->bindValue(3, $dtValidade);
            $stmt->bindValue(4, $qtdeProduto);
            $stmt->bindValue(5, $peso);
            $stmt->bindValue(6, $receita);
            $stmt->bindValue(7, $precoCompra);
            $stmt->bindValue(8, $precoVenda);
            $stmt->bindValue(9, $remedioControlado);
            $stmt->bindValue(10, $imgProduto);
            $stmt->bindValue(11, $dtEntrada);
            $stmt->bindValue(12, $categoria);
            $stmt->bindValue(13, $prateleira);
            $stmt->bindValue(14, $estoqueMinimo);

            return $stmt->execute();
            
        } catch (PDOException $exc) {

            echo $exc->getMessage();
        }
    }

    //Método alterarProduto
    // UPDATE
    public function alterarProduto(produtoDTO $produtoDTO)
    {
        try {
            $sql = "UPDATE `produto` SET `codigoBarra`= ?,`nomeProduto`= ?,`dtValidade`= ?,`qtdeProduto`= ?,`peso`= ?,`receita`= ?,`precoCompra`= ?,`precoVenda`= ?,`remedioControlado`= ?,`imgProduto`= ?,`dtEntrada`= ?,`categoria`= ?,`prateleira`= ?,`estoqueMinimo`= ? WHERE `idProduto` = ?";
            
            $stmt = $this->pdo->prepare($sql);
            $idProduto = $produtoDTO->getIdProduto();
            $codigoBarra = $produtoDTO->getCodigoBarra();
            $nomeProduto = $produtoDTO->getNomeProduto(); 
            $dtValidade = $produtoDTO->getDtValidade();
            $qtdeProduto = $produtoDTO->getQtdeProduto();
            $peso = $produtoDTO->getPeso();
            $receita = $produtoDTO->getReceita();
            $precoCompra = $produtoDTO->getPrecoCompra();
            $precoVenda = $produtoDTO->getPrecoVenda();
            $prescricaoMedica = $produtoDTO->getPrecoCompra();
            $remedioControlado = $produtoDTO->getRemedioControlado();
            $imgProduto = $produtoDTO->getImgProduto();
            $dtEntrada = $produtoDTO->getDtEntrada();
            $categoria = $produtoDTO->getCategoria();
            $prateleira = $produtoDTO->getPrateleira();
            $estoqueMinimo = $produtoDTO->getEstoqueMinimo();

            $stmt->bindValue(1, $codigoBarra);
            $stmt->bindValue(2, $nomeProduto);
            $stmt->bindValue(3, $dtValidade);
            $stmt->bindValue(4, $qtdeProduto);
            $stmt->bindValue(5, $peso);
            $stmt->bindValue(6, $receita);
            $stmt->bindValue(7, $precoCompra);
            $stmt->bindValue(8, $precoVenda);
            $stmt->bindValue(9, $remedioControlado);
            $stmt->bindValue(10, $imgProduto);
            $stmt->bindValue(11, $dtEntrada);
            $stmt->bindValue(12, $categoria);
            $stmt->bindValue(13, $prateleira);
            $stmt->bindValue(14, $estoqueMinimo);
            $stmt->bindValue(15, $idProduto);

            return $stmt->execute();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //fim médodo alterarProduto

    //Método excluirProduto
    public function excluirProduto($idProduto)
    {
        try {
            $sql = "DELETE FROM `produto` 
        WHERE `idProduto` = '{$idProduto}';";

            $stmt = $this->pdo->prepare($sql);

            $retorno = $stmt->execute();

            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim excluirProduto

    //pesquisarProduto
    public function pesquisarProdutoss()
    {
        try {
            $sql = "SELECT * FROM `produto`";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarProduto

    //PesquisarProdutoPorId
    public function pesquisarProdutoPorId($idProduto)
    {
        try {
            $sql = "SELECT * FROM `produto` WHERE idProduto = '{$idProduto}'";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim pesquisarUsuarioPorId

    //Função para saber a quantidade em estoque
    public function contarQuantidade()
    {
        try {
            $sql = "SELECT SUM(qtdeProduto) FROM `produto`;";
            $stmt = $this->pdo->prepare($sql);

            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    //Fim função

    public function pesquisarProduto($pesquisar)
    { 
        try {
         
            $sql = "SELECT * FROM `produto`
            WHERE nomeProduto LIKE '%{$pesquisar}%' ";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Descobrindo a quantidade de produtos em estoque
    public function qtdeProduto()
    { 
        try {
         
            $sql = "SELECT SUM(qtdeProduto) FROM `produto`;";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Descobrindo a quantia em estoque
    public function quantiaEstoque()
    { 
        try {
         
            $sql = "SELECT SUM(precoVenda * qtdeProduto) FROM `produto`;";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    //Descobrindo a quantidade vendida
    public function qtdeVendida()
    { 
        try {
         
            $sql = "SELECT SUM(qtdeItem) FROM pedido_has_produto;";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    
    //Descobrindo a itens que está faltando 15 dias para o vencimento
    public function qtdeVencimento()
    { 
        try {
         
            $sql = "SELECT SUM(qtdeProduto) FROM produto WHERE dtValidade >= CURRENT_DATE AND dtValidade <= CURRENT_DATE + INTERVAL 15 DAY;";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $retorno;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }



}
