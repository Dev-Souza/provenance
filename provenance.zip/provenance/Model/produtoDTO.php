<?php 
    class ProdutoDTO{
        private $idProduto;
        private $codigoBarra;
        private $nomeProduto;
        private $dtValidade;
        private $qtdeProduto;
        private $peso;
        private $receita;
        private $precoCompra;
        private $precoVenda;
        private $remedioControlado;
        private $imgProduto;
        private $dtEntrada;
        private $categoria;
        private $prateleira;
        private $estoqueMinimo;

        //Métodos setters
        public function setIdProduto($idProduto){
            $this->idProduto = $idProduto;
        } 
        public function setCodigoBarra($codigoBarra){
            $this->codigoBarra = $codigoBarra;
        } 
        public function setNomeProduto($nomeProduto){
            $this->nomeProduto = $nomeProduto;
        } 
        public function setDtValidade($dtValidade){
            $this->dtValidade = $dtValidade;
        } 
        public function setQtdeProduto($qtdeProduto){
            $this->qtdeProduto = $qtdeProduto;
        } 
        public function setPeso($peso){
            $this->peso = $peso;
        } 
        public function setReceita($receita){
            $this->receita = $receita;
        } 
        public function setPrecoCompra($precoCompra){
            $this->precoCompra = $precoCompra;
        } 
        public function setPrecoVenda($precoVenda){
            $this->precoVenda = $precoVenda;
        }
        public function setRemedioControlado($remedioControlado){
            $this->remedioControlado = $remedioControlado;
        } 
        public function setImgProduto($imgProduto){
            $this->imgProduto = $imgProduto;
        } 
        public function setDtEntrada($dtEntrada){
            $this->dtEntrada = $dtEntrada;
        } 
        public function setCategoria($categoria){
            $this->categoria = $categoria;
        } 
        public function setPrateleira($prateleira){
            $this->prateleira = $prateleira;
        } 
        public function setEstoqueMinimo($estoqueMinimo){
            $this->estoqueMinimo = $estoqueMinimo;
        }

        //Métodos getters
        public function getIdProduto(){
            return $this->idProduto;
        }
        public function getCodigoBarra(){
            return $this->codigoBarra;
        }
        public function getNomeProduto(){
            return $this->nomeProduto;
        }
        public function getDtValidade(){
            return $this->dtValidade;
        }
        public function getQtdeProduto(){
            return $this->qtdeProduto;
        }
        public function getPeso(){
            return $this->peso;
        }
        public function getReceita(){
            return $this->receita;
        }
        public function getPrecoCompra(){
            return $this->precoCompra;
        }
        public function getPrecoVenda(){
            return $this->precoVenda;
        }
        public function getRemedioControlado(){
            return $this->remedioControlado;
        }
        public function getImgProduto(){
            return $this->imgProduto;
        }
        public function getDtEntrada(){
            return $this->dtEntrada;
        }
        public function getCategoria(){
            return $this->categoria;
        }
        public function getPrateleira(){
            return $this->prateleira;
        }
        public function getEstoqueMinimo(){
            return $this->estoqueMinimo;
        }
}
